package com.bardia.visualizer.visualizers

import android.content.Context

class BirdsVisualizer(context: Context) : EmojiBaseVisualizer(
    context,
    listOf(
        "\uD83D\uDC26" to "پرنده", "\uD83E\uDD85" to "عقاب", "\uD83E\uDD89" to "جغد",
        "\uD83E\uDD9C" to "طوطی", "\uD83E\uDD86" to "اردک", "\uD83E\uDD9A" to "طاووس",
        "\uD83D\uDC14" to "خروس", "\uD83E\uDDA9" to "فلامینگو", "\uD83D\uDC27" to "پنگوئن",
        "\uD83D\uDD4A\uFE0F" to "کبوتر"
    ),
    lightBg = android.graphics.Color.parseColor("#E8F6FF"),
    darkBg = android.graphics.Color.parseColor("#0F1E2E")
)
