package com.bardia.visualizer.visualizers

import android.content.Context

class VehiclesVisualizer(context: Context) : EmojiBaseVisualizer(
    context,
    listOf(
        "\uD83D\uDE97" to "ماشین", "\uD83D\uDE8C" to "اتوبوس", "\uD83D\uDE92" to "آتش‌نشانی",
        "\uD83D\uDE93" to "پلیس", "\uD83D\uDE80" to "فضاپیما", "\u2708\uFE0F" to "هواپیما",
        "\uD83D\uDE81" to "هلیکوپتر", "\uD83D\uDEB2" to "دوچرخه", "\uD83D\uDE9A" to "کامیون",
        "\uD83D\uDE82" to "قطار"
    ),
    lightBg = android.graphics.Color.parseColor("#FFF7E0"),
    darkBg = android.graphics.Color.parseColor("#241D0E")
)
