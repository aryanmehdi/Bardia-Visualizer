package com.bardia.visualizer.visualizers

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

/**
 * The classic Winamp-style bar spectrum: many thin green->yellow->red
 * segmented bars with slowly-falling peak caps.
 */
class ClassicSpectrumVisualizer(context: Context) : BaseVisualizer(context) {

    private val barCount = 32
    private val heights = FloatArray(barCount)
    private val peaks = FloatArray(barCount)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onTick(deltaSeconds: Float) {
        val b = bass(); val m = mid(); val t = treble()
        for (i in 0 until barCount) {
            val frac = i / barCount.toFloat()
            val bandEnergy = b * (1f - frac) * 1.2f + m * (1f - kotlin.math.abs(frac - 0.5f) * 2f).coerceAtLeast(0f) + t * frac * 1.1f
            val jitter = 0.12f * kotlin.math.sin(time * (5f + i * 0.6f))
            val target = (0.1f + bandEnergy * 1.3f + jitter).coerceIn(0.05f, 1f)
            heights[i] += (target - heights[i]) * (deltaSeconds * 22f).coerceAtMost(1f)
            if (heights[i] >= peaks[i]) {
                peaks[i] = heights[i]
            } else {
                peaks[i] = (peaks[i] - deltaSeconds * 0.5f).coerceAtLeast(heights[i])
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        drawLivelyBackground(canvas, Color.parseColor("#000000"), Color.parseColor("#EDEDED"))
        val w = width.toFloat(); val h = height.toFloat()
        val gap = w * 0.006f
        val barW = (w - gap * (barCount + 1)) / barCount
        val baseY = h * 0.95f
        val maxH = h * 0.86f
        val segH = maxH / 22f
        val segGap = segH * 0.22f

        for (i in 0 until barCount) {
            val left = gap + i * (barW + gap)
            val litSegments = (heights[i] * 22).toInt()
            for (seg in 0 until 22) {
                val segTop = baseY - (seg + 1) * segH
                val frac = seg / 22f
                val color = when {
                    frac < 0.55f -> Color.rgb(30, (200 + frac * 100).toInt().coerceAtMost(255), 60)
                    frac < 0.8f -> Color.rgb(230, 210, 30)
                    else -> Color.rgb(235, 40, 40)
                }
                paint.color = color
                paint.alpha = if (seg < litSegments) 255 else if (isDarkTheme) 25 else 45
                canvas.drawRect(left, segTop + segGap / 2, left + barW, segTop + segH - segGap / 2, paint)
            }
            // peak cap
            val peakY = baseY - peaks[i] * maxH
            paint.color = Color.WHITE
            paint.alpha = 230
            canvas.drawRect(left, peakY - 5f, left + barW, peakY, paint)
        }
    }
}
