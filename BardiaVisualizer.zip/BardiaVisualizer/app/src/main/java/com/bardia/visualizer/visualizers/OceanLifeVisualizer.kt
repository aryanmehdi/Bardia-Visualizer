package com.bardia.visualizer.visualizers

import android.content.Context

class OceanLifeVisualizer(context: Context) : EmojiBaseVisualizer(
    context,
    listOf(
        "\uD83D\uDC20" to "ماهی", "\uD83D\uDC19" to "اختاپوس", "\uD83E\uDD80" to "خرچنگ",
        "\uD83D\uDC33" to "نهنگ", "\uD83D\uDC2C" to "دلفین", "\uD83D\uDC22" to "لاک‌پشت",
        "\uD83E\uDD88" to "ستاره‌دریایی", "\uD83E\uDD9E" to "میگو", "\uD83E\uDDAD" to "کوسه",
        "\uD83D\uDC1A" to "صدف"
    ),
    lightBg = android.graphics.Color.parseColor("#DFF7FF"),
    darkBg = android.graphics.Color.parseColor("#062A38")
)
