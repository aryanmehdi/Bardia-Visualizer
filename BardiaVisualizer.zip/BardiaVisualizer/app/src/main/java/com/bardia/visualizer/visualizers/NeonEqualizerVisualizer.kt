package com.bardia.visualizer.visualizers

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF

class NeonEqualizerVisualizer(context: Context) : BaseVisualizer(context) {

    private val barCount = 20
    private val heights = FloatArray(barCount)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var hueBase = 0f

    override fun onTick(deltaSeconds: Float) {
        hueBase = (hueBase + deltaSeconds * 25f) % 360f
        val b = bass(); val m = mid(); val t = treble()
        for (i in 0 until barCount) {
            val frac = i / barCount.toFloat()
            // low bars driven more by bass, high bars more by treble
            val bandEnergy = b * (1f - frac) + m * (1f - kotlin.math.abs(frac - 0.5f) * 2f).coerceAtLeast(0f) + t * frac
            val jitter = 0.15f * kotlin.math.sin(time * (4f + i * 0.5f))
            val target = (0.15f + bandEnergy * 1.35f + jitter).coerceIn(0.08f, 1f)
            heights[i] += (target - heights[i]) * (deltaSeconds * 20f).coerceAtMost(1f)
        }
    }

    override fun onDraw(canvas: Canvas) {
        drawLivelyBackground(canvas, Color.parseColor("#0A0A12"), Color.parseColor("#F5F5FA"))
        val w = width.toFloat(); val h = height.toFloat()
        val gap = w * 0.012f
        val barW = (w - gap * (barCount + 1)) / barCount
        val baseY = h * 0.94f
        val maxBarH = h * 0.88f

        for (i in 0 until barCount) {
            val bh = maxBarH * heights[i]
            val left = gap + i * (barW + gap)
            val top = baseY - bh
            val hue = (hueBase + i * (360f / barCount)) % 360f
            paint.color = Color.HSVToColor(floatArrayOf(hue, 0.8f, 1f))
            val rect = RectF(left, top, left + barW, baseY + 10f)
            canvas.drawRoundRect(rect, barW / 2f, barW / 2f, paint)
            // reflection
            paint.alpha = 70
            val reflect = RectF(left, baseY + 14f, left + barW, baseY + 14f + bh * 0.35f)
            canvas.drawRoundRect(reflect, barW / 2f, barW / 2f, paint)
            paint.alpha = 255
        }
    }
}
