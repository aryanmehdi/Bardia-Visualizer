package com.bardia.visualizer.visualizers

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path

/**
 * A rotating, breathing waveform tunnel - the classic Winamp AVS
 * "circular scope in a wormhole" look. The actual waveform is wrapped
 * around concentric rotating rings.
 */
class TunnelWaveVisualizer(context: Context) : BaseVisualizer(context) {

    private val ringCount = 6
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val path = Path()
    private var rotation = 0f

    override fun onTick(deltaSeconds: Float) {
        rotation = (rotation + deltaSeconds * (25f + bass() * 90f)) % 360f
    }

    override fun onDraw(canvas: Canvas) {
        drawLivelyBackground(canvas, Color.parseColor("#03040C"), Color.parseColor("#F4F0FF"))
        val cx = width / 2f; val cy = height / 2f
        val wf = frame?.waveform
        val maxR = kotlin.math.min(width, height) * 0.48f

        for (ring in 0 until ringCount) {
            val ringFrac = ring / (ringCount - 1f)
            val baseR = maxR * (0.2f + ringFrac * 0.8f)
            val dir = if (ring % 2 == 0) 1f else -1f
            val ringRotation = rotation * dir * (0.6f + ringFrac * 0.8f)
            val hue = (ringFrac * 300f + rotation * 2f) % 360f
            paint.color = Color.HSVToColor((255 - (ring * 20)).coerceIn(80, 255), floatArrayOf(hue, 0.7f, 1f))
            paint.strokeWidth = 5f + bass() * 6f

            path.reset()
            val steps = 96
            for (i in 0..steps) {
                val t = i / steps.toFloat()
                val sample = if (wf != null) {
                    val idx = (t * (wf.size - 1)).toInt().coerceIn(0, wf.size - 1)
                    ((wf[idx].toInt() and 0xFF) - 128) / 128f
                } else 0f
                val wobble = sample * maxR * 0.12f * (0.4f + amplitude())
                val r = baseR + wobble
                val ang = Math.toRadians((t * 360f + ringRotation).toDouble())
                val x = cx + kotlin.math.cos(ang).toFloat() * r
                val y = cy + kotlin.math.sin(ang).toFloat() * r
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            canvas.drawPath(path, paint)
        }

        paint.style = Paint.Style.FILL
        paint.color = Color.HSVToColor(floatArrayOf((rotation * 2f) % 360f, 0.4f, 1f))
        canvas.drawCircle(cx, cy, 18f + bass() * 26f, paint)
        paint.style = Paint.Style.STROKE
    }
}
