package com.bardia.visualizer.visualizers

import android.content.Context

class MammalsVisualizer(context: Context) : EmojiBaseVisualizer(
    context,
    listOf(
        "\uD83D\uDC0E" to "اسب", "\uD83D\uDC2E" to "گاو", "\uD83D\uDC11" to "گوسفند",
        "\uD83D\uDC10" to "بز", "\uD83D\uDC37" to "خوک", "\uD83D\uDC2D" to "موش",
        "\uD83E\uDD8F" to "کرگدن", "\uD83D\uDC0B" to "نهنگ", "\uD83E\uDD9F" to "خفاش",
        "\uD83D\uDC12" to "میمون"
    )
)
