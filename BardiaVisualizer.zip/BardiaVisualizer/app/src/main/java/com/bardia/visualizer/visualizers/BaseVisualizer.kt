package com.bardia.visualizer.visualizers

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import com.bardia.visualizer.audio.AudioFrame
import kotlin.random.Random

/**
 * Common base for every kid-friendly visualizer.
 * Provides a smooth ~60fps animation clock (`time`, seconds since start)
 * and the latest [AudioFrame] so subclasses can react to bass/mid/treble/beat.
 * Even with silence, `time` keeps advancing so shapes gently idle instead of
 * freezing (important for holding a toddler's attention).
 */
abstract class BaseVisualizer(context: Context) : View(context) {

    var frame: AudioFrame? = null
        private set

    var isDarkTheme: Boolean = true
        set(value) {
            field = value
            onThemeChanged(value)
            invalidate()
        }

    protected var time: Float = 0f
        private set

    private var lastTickNanos: Long = 0L

    private val clock = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 16
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            val now = System.nanoTime()
            var dt = 0f
            if (lastTickNanos != 0L) {
                dt = ((now - lastTickNanos) / 1_000_000_000f).coerceIn(0f, 0.05f)
                time += dt
            }
            lastTickNanos = now
            onTick(dt)
            invalidate()
        }
    }

    fun updateFrame(f: AudioFrame) {
        frame = f
    }

    fun resume() {
        lastTickNanos = 0L
        clock.start()
    }

    fun pause() {
        clock.cancel()
    }

    /** Called every frame before invalidate(); override for physics/particle updates. */
    protected open fun onTick(deltaSeconds: Float) {}

    /** Override to react to a light/dark palette switch. */
    protected open fun onThemeChanged(dark: Boolean) {}

    protected fun bass(): Float = frame?.bass ?: 0f
    protected fun mid(): Float = frame?.mid ?: 0f
    protected fun treble(): Float = frame?.treble ?: 0f
    protected fun amplitude(): Float = frame?.amplitude ?: 0f
    protected fun isBeat(): Boolean = frame?.beat ?: false
    protected fun isSilent(): Boolean = frame?.silent ?: true

    // ---------- Shared "lively" background: subtle drifting color blobs + soft grain ----------
    // Keeps every visualizer's backdrop from looking like a flat, boring fill,
    // without distracting from the foreground animation.

    private data class BgBlob(val xFrac: Float, val yFrac: Float, val radiusFrac: Float, val hueOffset: Float, val speed: Float, val phase: Float)

    private var bgBlobs: List<BgBlob>? = null
    private var sparkles: MutableList<FloatArray>? = null
    private val bgPaint by lazy { Paint(Paint.ANTI_ALIAS_FLAG) }
    private val sparklePaint by lazy { Paint(Paint.ANTI_ALIAS_FLAG) }
    private val hsvScratch = FloatArray(3)

    protected fun drawLivelyBackground(canvas: Canvas, colorDark: Int, colorLight: Int) {
        val base = if (isDarkTheme) colorDark else colorLight
        canvas.drawColor(base)
        if (width <= 0 || height <= 0) return

        if (bgBlobs == null) {
            bgBlobs = List(5) {
                BgBlob(
                    Random.nextFloat(), Random.nextFloat(),
                    0.28f + Random.nextFloat() * 0.28f,
                    Random.nextFloat() * 360f,
                    0.06f + Random.nextFloat() * 0.09f,
                    Random.nextFloat() * 6.28f
                )
            }
        }
        Color.colorToHSV(base, hsvScratch)
        val satBase = hsvScratch[1]
        val valBase = hsvScratch[2]

        for (b in bgBlobs!!) {
            val cx = (b.xFrac + kotlin.math.sin(time * b.speed + b.phase) * 0.10f) * width
            val cy = (b.yFrac + kotlin.math.cos(time * b.speed * 0.85f + b.phase) * 0.10f) * height
            val r = b.radiusFrac * kotlin.math.max(width, height)
            val hue = (hsvScratch[0] + b.hueOffset + time * 5f) % 360f
            val blobColor = Color.HSVToColor(
                floatArrayOf(hue, satBase.coerceAtLeast(0.35f).coerceAtMost(0.8f), valBase.coerceAtLeast(0.4f).coerceAtMost(1f))
            )
            bgPaint.shader = RadialGradient(
                cx, cy, r,
                Color.argb(34, Color.red(blobColor), Color.green(blobColor), Color.blue(blobColor)),
                Color.TRANSPARENT, Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, r, bgPaint)
        }
        bgPaint.shader = null

        val sp = sparkles ?: mutableListOf<FloatArray>().also { list ->
            repeat(22) { list.add(floatArrayOf(Random.nextFloat() * width, Random.nextFloat() * height, Random.nextFloat() * 6.28f)) }
            sparkles = list
        }
        for (s in sp) {
            val tw = 0.3f + 0.3f * kotlin.math.sin(time * 2.2f + s[2])
            sparklePaint.color = Color.WHITE
            sparklePaint.alpha = (tw * 70).toInt().coerceIn(0, 90)
            canvas.drawCircle(s[0], s[1], 2.4f, sparklePaint)
        }
    }
}
