package com.bardia.visualizer.visualizers

import android.animation.ValueAnimator
import android.content.Context
import android.view.View
import android.view.animation.LinearInterpolator
import com.bardia.visualizer.audio.AudioFrame

/**
 * Common base for every kid-friendly visualizer.
 * Provides a smooth ~60fps animation clock (`time`, seconds since start)
 * and the latest [AudioFrame] so subclasses can react to bass/mid/treble/beat.
 * Even with silence, `time` keeps advancing so shapes gently idle instead of
 * freezing (important for holding a toddler's attention).
 */
abstract class BaseVisualizer(context: Context) : View(context) {

    var frame: AudioFrame? = null
        private set

    var isDarkTheme: Boolean = true
        set(value) {
            field = value
            onThemeChanged(value)
            invalidate()
        }

    protected var time: Float = 0f
        private set

    private var lastTickNanos: Long = 0L

    private val clock = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 16
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            val now = System.nanoTime()
            var dt = 0f
            if (lastTickNanos != 0L) {
                dt = ((now - lastTickNanos) / 1_000_000_000f).coerceIn(0f, 0.05f)
                time += dt
            }
            lastTickNanos = now
            onTick(dt)
            invalidate()
        }
    }

    fun updateFrame(f: AudioFrame) {
        frame = f
    }

    fun resume() {
        lastTickNanos = 0L
        clock.start()
    }

    fun pause() {
        clock.cancel()
    }

    /** Called every frame before invalidate(); override for physics/particle updates. */
    protected open fun onTick(deltaSeconds: Float) {}

    /** Override to react to a light/dark palette switch. */
    protected open fun onThemeChanged(dark: Boolean) {}

    protected fun bass(): Float = frame?.bass ?: 0f
    protected fun mid(): Float = frame?.mid ?: 0f
    protected fun treble(): Float = frame?.treble ?: 0f
    protected fun amplitude(): Float = frame?.amplitude ?: 0f
    protected fun isBeat(): Boolean = frame?.beat ?: false
    protected fun isSilent(): Boolean = frame?.silent ?: true
}
