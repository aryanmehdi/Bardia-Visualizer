package com.bardia.visualizer.audio

import android.media.audiofx.Visualizer
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

/**
 * Captures the device's global audio output mix (session 0) so it reacts to
 * ANY sound being played on the TV — Bluetooth audio, local players, apps, etc.
 * No microphone, no root, no internal player needed.
 */
class AudioAnalyzer(private val listener: Listener) {

    interface Listener {
        // Called ~20x/sec with fresh audio data
        fun onAudioData(data: AudioFrame)
        fun onCaptureUnavailable()
    }

    private var visualizer: Visualizer? = null
    private var smoothedBass = 0f
    private var smoothedMid = 0f
    private var smoothedTreble = 0f
    private var lastBeatEnergy = 0f
    private var silenceCounter = 0

    fun start() {
        try {
            val captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024)
            visualizer = Visualizer(0).apply {
                setCaptureSize(captureSize)
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, samplingRate: Int) {
                        waveform ?: return
                        process(waveform, null)
                    }

                    override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                        fft ?: return
                        process(null, fft)
                    }
                }, Visualizer.getMaxCaptureRate() / 2, true, true)
                enabled = true
            }
        } catch (e: Exception) {
            listener.onCaptureUnavailable()
        }
    }

    fun stop() {
        try {
            visualizer?.enabled = false
            visualizer?.release()
        } catch (_: Exception) {
        }
        visualizer = null
    }

    private var lastWaveform: ByteArray? = null
    private var lastFft: ByteArray? = null

    private fun process(waveform: ByteArray?, fft: ByteArray?) {
        waveform?.let { lastWaveform = it }
        fft?.let { lastFft = it }
        val wf = lastWaveform ?: return
        val ff = lastFft ?: return

        // Compute overall amplitude (0..1) from waveform for beat/volume
        var sum = 0f
        for (b in wf) {
            val v = (b.toInt() and 0xFF) - 128
            sum += abs(v)
        }
        val amplitude = ((sum / wf.size) / 128f)

        // Split FFT magnitude spectrum into bass / mid / treble bands
        val bands = computeBands(ff)

        // Perceptual gain: boosts quiet/moderate audio so visuals stay lively
        // without feeling overwhelming. Tuned between raw and the earlier
        // overly-sensitive version.
        val gain = 1.85f
        fun boost(v: Float): Float = kotlin.math.sqrt((v * gain).coerceIn(0f, 1f))

        smoothedBass = smoothedBass * 0.55f + boost(bands.bass) * 0.45f
        smoothedMid = smoothedMid * 0.55f + boost(bands.mid) * 0.45f
        smoothedTreble = smoothedTreble * 0.55f + boost(bands.treble) * 0.45f

        val beat = detectBeat(smoothedBass)

        if (amplitude < 0.01f) {
            silenceCounter++
        } else {
            silenceCounter = 0
        }

        listener.onAudioData(
            AudioFrame(
                waveform = wf,
                amplitude = boost(amplitude).coerceIn(0f, 1f),
                bass = smoothedBass.coerceIn(0f, 1f),
                mid = smoothedMid.coerceIn(0f, 1f),
                treble = smoothedTreble.coerceIn(0f, 1f),
                beat = beat,
                silent = silenceCounter > 15
            )
        )
    }

    private data class Bands(val bass: Float, val mid: Float, val treble: Float)

    private fun computeBands(fft: ByteArray): Bands {
        // FFT array layout: Re0, Re(N/2), then Re1,Im1, Re2,Im2 ...
        val n = fft.size
        val magnitudes = FloatArray(n / 2)
        magnitudes[0] = abs(fft[0].toInt()).toFloat()
        for (i in 1 until n / 2) {
            val re = fft[i * 2].toInt().toFloat()
            val im = fft[i * 2 + 1].toInt().toFloat()
            magnitudes[i] = hypot(re, im)
        }
        val bassEnd = (magnitudes.size * 0.10f).toInt().coerceAtLeast(1)
        val midEnd = (magnitudes.size * 0.45f).toInt().coerceAtLeast(bassEnd + 1)

        val bass = average(magnitudes, 0, bassEnd) / 128f
        val mid = average(magnitudes, bassEnd, midEnd) / 128f
        val treble = average(magnitudes, midEnd, magnitudes.size) / 128f
        return Bands(bass, mid, treble)
    }

    private fun average(arr: FloatArray, from: Int, to: Int): Float {
        if (to <= from) return 0f
        var s = 0f
        for (i in from until to) s += arr[i]
        return s / (to - from)
    }

    private fun detectBeat(bassEnergy: Float): Boolean {
        val isBeat = bassEnergy > lastBeatEnergy * 1.15f && bassEnergy > 0.18f
        lastBeatEnergy = max(bassEnergy, lastBeatEnergy * 0.92f)
        return isBeat
    }
}

data class AudioFrame(
    val waveform: ByteArray,
    val amplitude: Float,
    val bass: Float,
    val mid: Float,
    val treble: Float,
    val beat: Boolean,
    val silent: Boolean
)
