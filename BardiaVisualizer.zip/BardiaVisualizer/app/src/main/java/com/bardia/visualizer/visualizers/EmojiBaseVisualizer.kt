package com.bardia.visualizer.visualizers

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import kotlin.random.Random

abstract class EmojiBaseVisualizer(
    context: Context,
    private val items: List<Pair<String, String>>,
    private val lightBg: Int = Color.parseColor("#FFF7E8"),
    private val darkBg: Int = Color.parseColor("#141225")
) : BaseVisualizer(context) {

    private data class Sprite(var x: Float, var y: Float, var vx: Float, var vy: Float, var itemIndex: Int, var wobble: Float, var baseSize: Float)

    private val sprites = mutableListOf<Sprite>()
    private val emojiPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val cardBgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cardBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 6f }

    private var featureIndex = -1
    private var featureTimer = 0f
    private var featureIntervalSec = 5f
    private var cardScale = 0f
    private var hueShift = 0f

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        sprites.clear()
        val count = 10
        repeat(count) {
            sprites.add(
                Sprite(
                    Random.nextFloat() * w, Random.nextFloat() * h * 0.85f + h * 0.08f,
                    (Random.nextFloat() - 0.5f) * 220f, (Random.nextFloat() - 0.5f) * 180f,
                    Random.nextInt(items.size), Random.nextFloat() * 6.28f,
                    0.85f + Random.nextFloat() * 0.75f
                )
            )
        }
        featureIndex = Random.nextInt(items.size)
        featureTimer = 0f
    }

    override fun onTick(deltaSeconds: Float) {
        val amp = amplitude(); val m = mid()
        hueShift = (hueShift + deltaSeconds * 20f) % 360f
        for (s in sprites) {
            s.x += s.vx * (1f + m * 1.1f) * deltaSeconds
            s.y += s.vy * (1f + m * 1.1f) * deltaSeconds
            if (s.x < 70f || s.x > width - 70f) s.vx *= -1f
            if (s.y < 100f || s.y > height - 70f) s.vy *= -1f
            s.x = s.x.coerceIn(50f, (width - 50f).coerceAtLeast(51f))
            s.y = s.y.coerceIn(90f, (height - 50f).coerceAtLeast(91f))
        }

        featureTimer += deltaSeconds
        if (featureTimer >= featureIntervalSec) {
            featureTimer = 0f
            featureIndex = (featureIndex + 1 + Random.nextInt(items.size - 1).let { if (items.size <= 1) 0 else it }) % items.size
            cardScale = 0.01f
        }
        if (cardScale in 0.01f..0.94f) {
            cardScale += (1f - cardScale) * (deltaSeconds * 12f).coerceAtMost(1f)
        } else if (cardScale > 0f) {
            cardScale = 1f
        }
    }

    override fun onDraw(canvas: Canvas) {
        drawLivelyBackground(canvas, darkBg, lightBg)
        val amp = amplitude(); val b = bass()

        for (s in sprites) {
            val (emoji, _) = items[s.itemIndex]
            val pulse = s.baseSize * (1f + b * 0.4f + 0.1f * kotlin.math.sin(time * 5f + s.wobble))
            emojiPaint.textSize = 92f * pulse
            canvas.save()
            canvas.translate(s.x, s.y)
            canvas.rotate(kotlin.math.sin(time * 2.4f + s.wobble) * (10f + amp * 18f))
            canvas.drawText(emoji, 0f, emojiPaint.textSize * 0.35f, emojiPaint)
            canvas.restore()
        }

        if (cardScale > 0.02f && featureIndex in items.indices) {
            val (emoji, name) = items[featureIndex]
            val cx = width / 2f; val cy = height / 2f
            val panelW = 620f * cardScale
            val panelH = 460f * cardScale
            cardBgPaint.color = if (isDarkTheme) Color.argb(225, 20, 18, 38) else Color.argb(235, 255, 255, 255)
            val rect = RectF(cx - panelW / 2, cy - panelH / 2, cx + panelW / 2, cy + panelH / 2)
            canvas.drawRoundRect(rect, 50f, 50f, cardBgPaint)

            cardBorderPaint.color = Color.HSVToColor(floatArrayOf(hueShift, 0.65f, 1f))
            canvas.drawRoundRect(rect, 50f, 50f, cardBorderPaint)

            emojiPaint.textSize = 230f * cardScale
            canvas.drawText(emoji, cx, cy - panelH * 0.08f, emojiPaint)

            labelPaint.textSize = 74f * cardScale
            labelPaint.color = if (isDarkTheme) Color.WHITE else Color.parseColor("#2A2A2A")
            canvas.drawText(name, cx, cy + panelH * 0.34f, labelPaint)
        }
    }
}
