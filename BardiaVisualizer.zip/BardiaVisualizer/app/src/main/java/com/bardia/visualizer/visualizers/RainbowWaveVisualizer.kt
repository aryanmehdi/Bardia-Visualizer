package com.bardia.visualizer.visualizers

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path

class RainbowWaveVisualizer(context: Context) : BaseVisualizer(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()
    private var hueBase = 0f
    private val lineCount = 7

    override fun onTick(deltaSeconds: Float) {
        hueBase = (hueBase + deltaSeconds * (20f + treble() * 80f)) % 360f
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(if (isDarkTheme) Color.parseColor("#12102A") else Color.parseColor("#FFF6E9"))
        val w = width.toFloat(); val h = height.toFloat()
        val cy = h / 2f
        val wf = frame?.waveform

        for (line in 0 until lineCount) {
            path.reset()
            val amp = (90f + mid() * 340f + bass() * 160f) * (1f - line * 0.1f)
            val yOffset = (line - lineCount / 2f) * 30f
            val phase = time * (2.6f + line * 0.3f + amplitude() * 3f)
            val hue = (hueBase + line * (360f / lineCount)) % 360f
            paint.strokeWidth = 10f - line * 0.8f
            paint.color = Color.HSVToColor(200, floatArrayOf(hue, 0.75f, 1f))

            val steps = 64
            for (i in 0..steps) {
                val t = i / steps.toFloat()
                val x = t * w
                val sample = if (wf != null) {
                    val idx = (t * (wf.size - 1)).toInt().coerceIn(0, wf.size - 1)
                    ((wf[idx].toInt() and 0xFF) - 128) / 128f
                } else 0f
                val y = cy + yOffset + kotlin.math.sin(t * 10f + phase) * amp * 0.5f + sample * amp * 0.6f
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, paint)
        }
    }
}
