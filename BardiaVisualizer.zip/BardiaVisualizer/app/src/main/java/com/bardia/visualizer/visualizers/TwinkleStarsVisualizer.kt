package com.bardia.visualizer.visualizers

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.random.Random

class TwinkleStarsVisualizer(context: Context) : BaseVisualizer(context) {

    private data class Star(val x: Float, val y: Float, val size: Float, val phase: Float, val hue: Float)
    private data class Shooter(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val hue: Float)

    private val stars = mutableListOf<Star>()
    private val shooters = mutableListOf<Shooter>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var lastShoot = 0f
    private var flashAlpha = 0f

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        stars.clear()
        repeat(110) {
            stars.add(
                Star(
                    Random.nextFloat() * w, Random.nextFloat() * h * 0.9f,
                    5f + Random.nextFloat() * 13f, Random.nextFloat() * 6.28f,
                    Random.nextFloat() * 360f
                )
            )
        }
    }

    override fun onTick(deltaSeconds: Float) {
        lastShoot += deltaSeconds
        val shootInterval = 1.0f - (mid() * 0.6f)
        if ((isBeat() || lastShoot > shootInterval) && lastShoot > 0.25f && width > 0) {
            lastShoot = 0f
            repeat(if (isBeat()) 2 else 1) {
                shooters.add(
                    Shooter(
                        Random.nextFloat() * width * 0.6f, Random.nextFloat() * height * 0.3f,
                        420f + Random.nextFloat() * 380f, 200f + Random.nextFloat() * 160f, 1f,
                        Random.nextFloat() * 360f
                    )
                )
            }
        }
        val it = shooters.iterator()
        while (it.hasNext()) {
            val s = it.next()
            s.x += s.vx * deltaSeconds
            s.y += s.vy * deltaSeconds
            s.life -= deltaSeconds * 0.7f
            if (s.life <= 0f || s.y > height || s.x > width) it.remove()
        }

        // Big beat flash makes the whole sky pulse with excitement
        flashAlpha = (flashAlpha - deltaSeconds * 1.8f).coerceAtLeast(0f)
        if (isBeat() && bass() > 0.35f) flashAlpha = 0.35f
    }

    override fun onDraw(canvas: Canvas) {
        drawLivelyBackground(canvas, Color.parseColor("#050818"), Color.parseColor("#BFE3FF"))
        val tre = treble(); val b = bass()
        for (s in stars) {
            val twinkle = 0.5f + 0.5f * kotlin.math.sin(time * (4f + tre * 10f) + s.phase)
            val r = s.size * (0.7f + twinkle * 1.0f + b * 0.6f)
            val color = Color.HSVToColor(floatArrayOf(s.hue, 0.4f, 1f))
            paint.shader = RadialGradient(s.x, s.y, r * 2.4f, color, Color.TRANSPARENT, Shader.TileMode.CLAMP)
            paint.alpha = (150 + twinkle * 105).toInt()
            canvas.drawCircle(s.x, s.y, r * 2.4f, paint)
            paint.shader = null
            // crisp bright core so stars read clearly, not just a blurry glow
            paint.color = Color.WHITE
            paint.alpha = (200 + twinkle * 55).toInt().coerceIn(0, 255)
            canvas.drawCircle(s.x, s.y, r * 0.42f, paint)
        }
        paint.shader = null
        for (s in shooters) {
            paint.color = Color.HSVToColor((s.life * 255).toInt().coerceIn(0, 255), floatArrayOf(s.hue, 0.3f, 1f))
            canvas.drawCircle(s.x, s.y, 10f, paint)
            canvas.drawLine(s.x, s.y, s.x - s.vx * 0.1f, s.y - s.vy * 0.1f, paint)
        }
        if (flashAlpha > 0f) {
            paint.color = Color.argb((flashAlpha * 255).toInt().coerceIn(0, 255), 255, 255, 255)
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        }
    }
}
