package com.bardia.visualizer.visualizers

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.random.Random

class TwinkleStarsVisualizer(context: Context) : BaseVisualizer(context) {

    private data class Star(val x: Float, val y: Float, val size: Float, val phase: Float, val hue: Float)
    private data class Shooter(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float)

    private val stars = mutableListOf<Star>()
    private val shooters = mutableListOf<Shooter>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var lastShoot = 0f

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        stars.clear()
        repeat(60) {
            stars.add(
                Star(
                    Random.nextFloat() * w, Random.nextFloat() * h * 0.85f,
                    4f + Random.nextFloat() * 10f, Random.nextFloat() * 6.28f,
                    Random.nextFloat() * 360f
                )
            )
        }
    }

    override fun onTick(deltaSeconds: Float) {
        lastShoot += deltaSeconds
        if (isBeat() && lastShoot > 0.6f && width > 0) {
            lastShoot = 0f
            shooters.add(Shooter(Random.nextFloat() * width * 0.4f, 0f, 500f + Random.nextFloat() * 200f, 220f, 1f))
        }
        val it = shooters.iterator()
        while (it.hasNext()) {
            val s = it.next()
            s.x += s.vx * deltaSeconds
            s.y += s.vy * deltaSeconds
            s.life -= deltaSeconds * 0.8f
            if (s.life <= 0f || s.y > height) it.remove()
        }
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(if (isDarkTheme) Color.parseColor("#050818") else Color.parseColor("#BFE3FF"))
        val tre = treble()
        for (s in stars) {
            val twinkle = 0.5f + 0.5f * kotlin.math.sin(time * (2f + tre * 6f) + s.phase)
            val r = s.size * (0.6f + twinkle * 0.7f + bass() * 0.4f)
            val color = Color.HSVToColor(floatArrayOf(s.hue, 0.35f, 1f))
            paint.shader = RadialGradient(s.x, s.y, r * 2.2f, color, Color.TRANSPARENT, Shader.TileMode.CLAMP)
            paint.alpha = (150 + twinkle * 105).toInt()
            canvas.drawCircle(s.x, s.y, r * 2.2f, paint)
        }
        paint.shader = null
        paint.color = Color.WHITE
        for (s in shooters) {
            paint.alpha = (s.life * 255).toInt().coerceIn(0, 255)
            canvas.drawCircle(s.x, s.y, 8f, paint)
            canvas.drawLine(s.x, s.y, s.x - s.vx * 0.08f, s.y - s.vy * 0.08f, paint)
        }
    }
}
