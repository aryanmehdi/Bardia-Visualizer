package com.bardia.visualizer.visualizers

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path

/**
 * Classic green phosphor oscilloscope, just like old Winamp / media-player
 * waveform scopes, with a soft glow and a scanline grid.
 */
class OscilloscopeVisualizer(context: Context) : BaseVisualizer(context) {

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 2f }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()
    private var hue = 120f

    override fun onTick(deltaSeconds: Float) {
        hue = (hue + deltaSeconds * (10f + treble() * 60f)) % 360f
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(if (isDarkTheme) Color.parseColor("#050A05") else Color.parseColor("#E8FFE8"))
        val w = width.toFloat(); val h = height.toFloat()

        gridPaint.color = if (isDarkTheme) Color.argb(40, 0, 255, 100) else Color.argb(60, 0, 130, 0)
        val rows = 8; val cols = 14
        for (i in 0..rows) canvas.drawLine(0f, h * i / rows, w, h * i / rows, gridPaint)
        for (i in 0..cols) canvas.drawLine(w * i / cols, 0f, w * i / cols, h, gridPaint)

        val wf = frame?.waveform
        val cy = h / 2f
        val amp = (h * 0.42f) * (1f + amplitude() * 0.6f)

        path.reset()
        if (wf != null) {
            val steps = wf.size
            for (i in wf.indices) {
                val x = i / (steps - 1f) * w
                val sample = ((wf[i].toInt() and 0xFF) - 128) / 128f
                val y = cy + sample * amp
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
        } else {
            path.moveTo(0f, cy); path.lineTo(w, cy)
        }

        val glowColor = Color.HSVToColor(floatArrayOf(hue, 0.55f, 1f))
        glowPaint.color = glowColor
        glowPaint.alpha = 90
        glowPaint.strokeWidth = 18f
        canvas.drawPath(path, glowPaint)

        corePaint.color = Color.WHITE
        corePaint.strokeWidth = 4f
        canvas.drawPath(path, corePaint)

        corePaint.color = glowColor
        corePaint.strokeWidth = 2.5f
        canvas.drawPath(path, corePaint)
    }
}
