package com.bardia.visualizer.visualizers

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.random.Random

class PlayfulCloudsVisualizer(context: Context) : BaseVisualizer(context) {

    private data class Cloud(var x: Float, val y: Float, val size: Float, val speed: Float, val hue: Float)

    private val clouds = mutableListOf<Cloud>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        clouds.clear()
        repeat(7) {
            clouds.add(Cloud(Random.nextFloat() * w, h * (0.1f + Random.nextFloat() * 0.55f), 70f + Random.nextFloat() * 70f, 20f + Random.nextFloat() * 30f, Random.nextFloat() * 60f))
        }
    }

    override fun onTick(deltaSeconds: Float) {
        for (c in clouds) {
            c.x += (c.speed + mid() * 150f + (if (isBeat()) 70f else 0f)) * deltaSeconds
            if (c.x - c.size > width) c.x = -c.size
        }
    }

    override fun onDraw(canvas: Canvas) {
        drawLivelyBackground(canvas, Color.parseColor("#1C2440"), Color.parseColor("#AEE1FF"))
        val cx = width * 0.82f; val cy = height * 0.22f
        val glowR = 90f + bass() * 40f
        paint.shader = RadialGradient(
            cx, cy, glowR * 2.2f,
            if (isDarkTheme) Color.parseColor("#E8E8FF") else Color.parseColor("#FFF3B0"),
            Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, glowR * 2.2f, paint)
        paint.shader = null
        paint.color = if (isDarkTheme) Color.parseColor("#F5F5FF") else Color.parseColor("#FFE072")
        canvas.drawCircle(cx, cy, glowR * 0.65f, paint)

        for (c in clouds) {
            val squish = 1f + kotlin.math.sin(time * 1.4f + c.hue) * 0.08f + treble() * 0.1f
            paint.color = Color.HSVToColor(if (isDarkTheme) 235 else 255, floatArrayOf(c.hue, 0.15f, 1f))
            val r = c.size * squish
            canvas.drawCircle(c.x, c.y, r * 0.55f, paint)
            canvas.drawCircle(c.x - r * 0.55f, c.y + r * 0.15f, r * 0.4f, paint)
            canvas.drawCircle(c.x + r * 0.55f, c.y + r * 0.15f, r * 0.42f, paint)
            canvas.drawCircle(c.x + r * 0.15f, c.y - r * 0.2f, r * 0.38f, paint)
        }
    }
}
