package com.bardia.visualizer.visualizers

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

/**
 * Radial spectrum bars bursting outward from a center circle, like the
 * classic "AudioGlow circle" preset.
 */
class CircularSpectrumVisualizer(context: Context) : BaseVisualizer(context) {

    private val barCount = 60
    private val heights = FloatArray(barCount)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private var rotation = 0f

    override fun onTick(deltaSeconds: Float) {
        rotation = (rotation + deltaSeconds * (14f + mid() * 40f)) % 360f
        val b = bass(); val m = mid(); val t = treble()
        for (i in 0 until barCount) {
            val frac = i / barCount.toFloat()
            val bandEnergy = b * (1f - frac) + m * (1f - kotlin.math.abs(frac - 0.5f) * 2f).coerceAtLeast(0f) + t * frac
            val jitter = 0.1f * kotlin.math.sin(time * (6f + i * 0.3f))
            val target = (0.12f + bandEnergy * 1.3f + jitter).coerceIn(0.05f, 1f)
            heights[i] += (target - heights[i]) * (deltaSeconds * 18f).coerceAtMost(1f)
        }
    }

    override fun onDraw(canvas: Canvas) {
        drawLivelyBackground(canvas, Color.parseColor("#08060F"), Color.parseColor("#FFF4EE"))
        val cx = width / 2f; val cy = height / 2f
        val innerR = kotlin.math.min(width, height) * 0.14f + bass() * 30f
        val maxLen = kotlin.math.min(width, height) * 0.42f

        paint.color = Color.HSVToColor(floatArrayOf((rotation * 3f) % 360f, 0.5f, 1f))
        canvas.drawCircle(cx, cy, innerR, paint)

        paint.strokeWidth = (360f / barCount) * (Math.PI.toFloat() * innerR / 180f) * 0.7f + 4f
        for (i in 0 until barCount) {
            val angle = Math.toRadians((i * 360f / barCount + rotation).toDouble())
            val len = maxLen * heights[i]
            val x0 = cx + kotlin.math.cos(angle).toFloat() * innerR
            val y0 = cy + kotlin.math.sin(angle).toFloat() * innerR
            val x1 = cx + kotlin.math.cos(angle).toFloat() * (innerR + len)
            val y1 = cy + kotlin.math.sin(angle).toFloat() * (innerR + len)
            val hue = (i * 360f / barCount + rotation * 2f) % 360f
            paint.color = Color.HSVToColor(floatArrayOf(hue, 0.8f, 1f))
            canvas.drawLine(x0, y0, x1, y1, paint)
        }
    }
}
