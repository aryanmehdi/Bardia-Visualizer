package com.bardia.visualizer.visualizers

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import kotlin.random.Random

class FishTankVisualizer(context: Context) : BaseVisualizer(context) {

    private data class Fish(var x: Float, val y: Float, var dir: Int, val size: Float, val hue: Float, val speedMul: Float, val phase: Float)
    private data class Bubble(var x: Float, var y: Float, val size: Float)

    private val fishes = mutableListOf<Fish>()
    private val bubbles = mutableListOf<Bubble>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        fishes.clear()
        repeat(8) {
            fishes.add(
                Fish(
                    Random.nextFloat() * w, h * (0.2f + Random.nextFloat() * 0.65f),
                    if (Random.nextBoolean()) 1 else -1,
                    40f + Random.nextFloat() * 40f,
                    Random.nextFloat() * 360f,
                    0.7f + Random.nextFloat() * 0.8f,
                    Random.nextFloat() * 6.28f
                )
            )
        }
        bubbles.clear()
        repeat(20) { bubbles.add(Bubble(Random.nextFloat() * w, Random.nextFloat() * h, 4f + Random.nextFloat() * 10f)) }
    }

    override fun onTick(deltaSeconds: Float) {
        val speed = (110f + mid() * 340f + (if (isBeat()) 120f else 0f))
        for (f in fishes) {
            f.x += f.dir * speed * f.speedMul * deltaSeconds
            if (f.x > width + 80f) f.x = -80f
            if (f.x < -80f) f.x = width + 80f
        }
        for (b in bubbles) {
            b.y -= (30f + treble() * 90f) * deltaSeconds
            if (b.y < -20f) b.y = height + 20f
        }
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(if (isDarkTheme) Color.parseColor("#062033") else Color.parseColor("#BFEFFF"))

        paint.color = if (isDarkTheme) Color.argb(90, 255, 255, 255) else Color.argb(120, 255, 255, 255)
        for (b in bubbles) canvas.drawCircle(b.x, b.y, b.size, paint)

        for (f in fishes) {
            val wob = kotlin.math.sin(time * 6f + f.phase) * (6f + bass() * 14f)
            canvas.save()
            canvas.translate(f.x, f.y + wob)
            canvas.scale(f.dir.toFloat(), 1f)
            paint.color = Color.HSVToColor(floatArrayOf((f.hue + time * 10f) % 360f, 0.65f, 1f))

            path.reset()
            path.moveTo(-f.size, 0f)
            path.quadTo(0f, -f.size * 0.6f, f.size, 0f)
            path.quadTo(0f, f.size * 0.6f, -f.size, 0f)
            canvas.drawPath(path, paint)

            // tail
            val tailFlap = kotlin.math.sin(time * 10f + f.phase) * 12f
            path.reset()
            path.moveTo(-f.size, 0f)
            path.lineTo(-f.size - 28f, -20f + tailFlap)
            path.lineTo(-f.size - 28f, 20f + tailFlap)
            path.close()
            canvas.drawPath(path, paint)

            // eye
            paint.color = Color.WHITE
            canvas.drawCircle(f.size * 0.45f, -f.size * 0.1f, f.size * 0.16f, paint)
            paint.color = Color.BLACK
            canvas.drawCircle(f.size * 0.48f, -f.size * 0.1f, f.size * 0.08f, paint)
            canvas.restore()
        }
    }
}
