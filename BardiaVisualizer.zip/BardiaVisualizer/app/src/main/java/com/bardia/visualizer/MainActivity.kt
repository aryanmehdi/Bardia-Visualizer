package com.bardia.visualizer

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.bardia.visualizer.audio.AudioAnalyzer
import com.bardia.visualizer.audio.AudioFrame
import com.bardia.visualizer.visualizers.BaseVisualizer
import com.bardia.visualizer.visualizers.VisualizerType

class MainActivity : AppCompatActivity(), AudioAnalyzer.Listener {

    private lateinit var container: FrameLayout
    private lateinit var menuPanel: LinearLayout
    private lateinit var visualizerList: LinearLayout
    private lateinit var btnAutoRotate: Button
    private lateinit var btnTheme: Button

    private var currentView: BaseVisualizer? = null
    private var currentIndex = 0
    private var autoRotate = true
    private var isDarkTheme = true

    private lateinit var prefs: android.content.SharedPreferences
    private var analyzer: AudioAnalyzer? = null

    private val mainHandler = Handler(Looper.getMainLooper())
    private val rotateRunnable = object : Runnable {
        override fun run() {
            if (autoRotate) {
                selectVisualizer((currentIndex + 1) % VisualizerType.values().size)
            }
            mainHandler.postDelayed(this, ROTATE_INTERVAL_MS)
        }
    }
    private val hideMenuRunnable = Runnable { hideMenu() }

    companion object {
        private const val ROTATE_INTERVAL_MS = 30_000L
        private const val AUTO_HIDE_MS = 6_000L
        private const val REQ_AUDIO = 42
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("bardia_prefs", MODE_PRIVATE)
        currentIndex = prefs.getInt("last_index", 0)
        autoRotate = prefs.getBoolean("auto_rotate", true)
        isDarkTheme = prefs.getBoolean("dark_theme", true)

        container = findViewById(R.id.visualizerContainer)
        menuPanel = findViewById(R.id.menuPanel)
        visualizerList = findViewById(R.id.visualizerList)
        btnAutoRotate = findViewById(R.id.btnAutoRotate)
        btnTheme = findViewById(R.id.btnTheme)

        buildMenuItems()
        updateToggleLabels()
        selectVisualizer(currentIndex)

        btnAutoRotate.setOnClickListener {
            autoRotate = !autoRotate
            prefs.edit().putBoolean("auto_rotate", autoRotate).apply()
            updateToggleLabels()
            scheduleAutoHide()
        }
        btnTheme.setOnClickListener {
            isDarkTheme = !isDarkTheme
            prefs.edit().putBoolean("dark_theme", isDarkTheme).apply()
            currentView?.isDarkTheme = isDarkTheme
            updateToggleLabels()
            scheduleAutoHide()
        }

        ensurePermissionThenStartAudio()
        hideSystemBars()
        mainHandler.postDelayed(rotateRunnable, ROTATE_INTERVAL_MS)
    }

    private fun buildMenuItems() {
        visualizerList.removeAllViews()
        VisualizerType.values().forEachIndexed { index, type ->
            val b = Button(this, null, 0, R.style.VisualizerChip)
            b.text = type.displayName
            b.isSelected = index == currentIndex
            b.setOnClickListener {
                selectVisualizer(index)
                scheduleAutoHide()
            }
            visualizerList.addView(b)
        }
    }

    private fun selectVisualizer(index: Int) {
        currentIndex = index
        prefs.edit().putInt("last_index", index).apply()
        container.removeAllViews()
        val type = VisualizerType.values()[index]
        val view = VisualizerType.create(this, type)
        view.isDarkTheme = isDarkTheme
        view.layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        container.addView(view)
        currentView?.pause()
        currentView = view
        view.resume()

        for (i in 0 until visualizerList.childCount) {
            visualizerList.getChildAt(i).isSelected = i == index
        }
    }

    private fun updateToggleLabels() {
        btnAutoRotate.text = (if (autoRotate) "✓ " else "") + getString(R.string.menu_auto_rotate)
        btnTheme.text = getString(if (isDarkTheme) R.string.menu_theme_dark else R.string.menu_theme_light)
    }

    // ---------- Audio capture ----------

    private fun ensurePermissionThenStartAudio() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startAudio()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), REQ_AUDIO)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_AUDIO) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startAudio()
            } else {
                Toast.makeText(this, R.string.menu_permission_needed, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startAudio() {
        if (analyzer != null) return
        analyzer = AudioAnalyzer(this).also { it.start() }
    }

    override fun onAudioData(data: AudioFrame) {
        currentView?.updateFrame(data)
    }

    override fun onCaptureUnavailable() {
        runOnUiThread {
            Toast.makeText(this, R.string.menu_permission_needed, Toast.LENGTH_LONG).show()
        }
    }

    // ---------- Menu / fullscreen ----------

    private fun toggleMenu() {
        if (menuPanel.visibility == View.VISIBLE) hideMenu() else showMenu()
    }

    private fun showMenu() {
        menuPanel.visibility = View.VISIBLE
        visualizerList.getChildAt(currentIndex)?.requestFocus()
        scheduleAutoHide()
    }

    private fun hideMenu() {
        menuPanel.visibility = View.GONE
        mainHandler.removeCallbacks(hideMenuRunnable)
    }

    private fun scheduleAutoHide() {
        mainHandler.removeCallbacks(hideMenuRunnable)
        mainHandler.postDelayed(hideMenuRunnable, AUTO_HIDE_MS)
    }

    private fun hideSystemBars() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                if (menuPanel.visibility != View.VISIBLE) {
                    toggleMenu()
                    return true
                }
            }
            KeyEvent.KEYCODE_BACK -> {
                if (menuPanel.visibility == View.VISIBLE) {
                    hideMenu()
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (menuPanel.visibility != View.VISIBLE) {
                    showMenu()
                    return true
                } else {
                    scheduleAutoHide()
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onResume() {
        super.onResume()
        currentView?.resume()
    }

    override fun onPause() {
        super.onPause()
        currentView?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        mainHandler.removeCallbacksAndMessages(null)
        analyzer?.stop()
    }
}
