package com.bardia.visualizer.visualizers

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import kotlin.random.Random

class GalaxySpiralVisualizer(context: Context) : BaseVisualizer(context) {

    private data class Particle(var angle: Float, var radius: Float, val speed: Float, val hue: Float, val size: Float)

    private val particles = mutableListOf<Particle>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        particles.clear()
        val maxR = kotlin.math.min(w, h) / 2f
        repeat(140) {
            particles.add(
                Particle(
                    Random.nextFloat() * 360f,
                    Random.nextFloat() * maxR,
                    (0.3f + Random.nextFloat() * 0.7f) * if (Random.nextBoolean()) 1f else -1f,
                    Random.nextFloat() * 360f,
                    4f + Random.nextFloat() * 8f
                )
            )
        }
    }

    override fun onTick(deltaSeconds: Float) {
        val spin = 30f + bass() * 220f
        for (p in particles) {
            p.angle = (p.angle + p.speed * spin * deltaSeconds) % 360f
        }
        if (isBeat() && particles.size < 220) {
            val maxR = kotlin.math.min(width, height) / 2f
            particles.add(Particle(Random.nextFloat() * 360f, 6f, (0.5f + Random.nextFloat() * 0.6f), Random.nextFloat() * 360f, 6f + Random.nextFloat() * 6f))
        }
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(if (isDarkTheme) Color.parseColor("#08061A") else Color.parseColor("#FFF0FA"))
        val cx = width / 2f; val cy = height / 2f
        val maxR = kotlin.math.min(width, height) / 2f

        paint.color = Color.HSVToColor(floatArrayOf((time * 20f) % 360f, 0.5f, 1f))
        canvas.drawCircle(cx, cy, 26f + amplitude() * 30f, paint)

        for (p in particles) {
            val growR = (p.radius + time * 4f * kotlin.math.abs(p.speed)) % maxR
            val rad = Math.toRadians(p.angle.toDouble())
            val armOffset = kotlin.math.sin(growR * 0.05f + time) * 20f
            val x = cx + kotlin.math.cos(rad).toFloat() * growR
            val y = cy + kotlin.math.sin(rad).toFloat() * growR + armOffset * 0f
            val hue = (p.hue + time * 30f) % 360f
            paint.color = Color.HSVToColor((180 + treble() * 75).toInt().coerceIn(0, 255), floatArrayOf(hue, 0.7f, 1f))
            canvas.drawCircle(x, y, p.size * (0.8f + mid() * 0.6f), paint)
        }
    }
}
