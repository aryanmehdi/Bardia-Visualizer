package com.bardia.visualizer.visualizers

import android.content.Context

class ObjectsVisualizer(context: Context) : EmojiBaseVisualizer(
    context,
    listOf(
        "\u26BD" to "توپ", "\uD83E\uDDF8" to "عروسک", "\uD83D\uDCDA" to "کتاب",
        "\u270F\uFE0F" to "مداد", "\u23F0" to "ساعت", "\uD83C\uDFA8" to "نقاشی",
        "\uD83D\uDD11" to "کلید", "\uD83C\uDFAA" to "بادکنک", "\u2614" to "چتر",
        "\uD83C\uDFB8" to "گیتار"
    ),
    lightBg = android.graphics.Color.parseColor("#F2F0FF"),
    darkBg = android.graphics.Color.parseColor("#191428")
)
