package com.bardia.visualizer.visualizers

import android.content.Context

enum class VisualizerType(val displayName: String) {
    BUBBLES("حباب‌های رنگی"),
    RAINBOW_WAVE("رنگین‌کمان موجی"),
    TWINKLE_STARS("ستاره‌های چشمک‌زن"),
    BLOOMING_FLOWERS("گل‌های در حال رشد"),
    FLYING_BALLOONS("بادکنک‌های پرنده"),
    FISH_TANK("ماهی‌های شناور"),
    PULSE_RINGS("دایره‌های نبض‌دار"),
    PLAYFUL_CLOUDS("ابرهای بازیگوش"),
    NEON_EQUALIZER("راه‌راه نئونی"),
    GALAXY_SPIRAL("کهکشان چرخان");

    companion object {
        fun create(context: Context, type: VisualizerType): BaseVisualizer = when (type) {
            BUBBLES -> BubblesVisualizer(context)
            RAINBOW_WAVE -> RainbowWaveVisualizer(context)
            TWINKLE_STARS -> TwinkleStarsVisualizer(context)
            BLOOMING_FLOWERS -> BloomingFlowersVisualizer(context)
            FLYING_BALLOONS -> FlyingBalloonsVisualizer(context)
            FISH_TANK -> FishTankVisualizer(context)
            PULSE_RINGS -> PulseRingsVisualizer(context)
            PLAYFUL_CLOUDS -> PlayfulCloudsVisualizer(context)
            NEON_EQUALIZER -> NeonEqualizerVisualizer(context)
            GALAXY_SPIRAL -> GalaxySpiralVisualizer(context)
        }
    }
}
