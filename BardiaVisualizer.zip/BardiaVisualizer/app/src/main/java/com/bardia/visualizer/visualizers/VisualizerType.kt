package com.bardia.visualizer.visualizers

import android.content.Context

enum class VisualizerType(val displayName: String) {
    BUBBLES("حباب‌های رنگی"),
    RAINBOW_WAVE("رنگین‌کمان موجی"),
    TWINKLE_STARS("ستاره‌های چشمک‌زن"),
    BLOOMING_FLOWERS("باغ گل و پروانه"),
    FLYING_BALLOONS("بادکنک‌های پرنده"),
    FISH_TANK("ماهی‌های شناور"),
    PULSE_RINGS("دایره‌های نبض‌دار"),
    PLAYFUL_CLOUDS("ابرهای بازیگوش"),
    NEON_EQUALIZER("راه‌راه نئونی"),
    GALAXY_SPIRAL("کهکشان چرخان"),

    ANIMALS("حیوانات"),
    MAMMALS("پستانداران"),
    BIRDS("پرندگان"),
    FRUITS("میوه‌ها"),
    OBJECTS("وسایل"),
    CLOTHES("لباس‌ها"),
    SEASONS("فصل‌ها"),
    OCEAN_LIFE("زیر دریا"),
    VEHICLES("وسایل نقلیه"),
    SHAPES_COLORS("اشکال و رنگ‌ها"),
    FOOD_DRINKS("غذا، دسر و نوشیدنی"),

    CLASSIC_SPECTRUM("اسپکتروم کلاسیک"),
    COLOR_GRID("گرید رنگین‌کمانی"),
    CIRCULAR_SPECTRUM("طیف دایره‌ای"),
    VU_METERS("VU متر آنالوگ"),
    TUNNEL_WAVE("تونل موج");

    companion object {
        fun create(context: Context, type: VisualizerType): BaseVisualizer = when (type) {
            BUBBLES -> BubblesVisualizer(context)
            RAINBOW_WAVE -> RainbowWaveVisualizer(context)
            TWINKLE_STARS -> TwinkleStarsVisualizer(context)
            BLOOMING_FLOWERS -> BloomingFlowersVisualizer(context)
            FLYING_BALLOONS -> FlyingBalloonsVisualizer(context)
            FISH_TANK -> FishTankVisualizer(context)
            PULSE_RINGS -> PulseRingsVisualizer(context)
            PLAYFUL_CLOUDS -> PlayfulCloudsVisualizer(context)
            NEON_EQUALIZER -> NeonEqualizerVisualizer(context)
            GALAXY_SPIRAL -> GalaxySpiralVisualizer(context)

            ANIMALS -> AnimalsVisualizer(context)
            MAMMALS -> MammalsVisualizer(context)
            BIRDS -> BirdsVisualizer(context)
            FRUITS -> FruitsVisualizer(context)
            OBJECTS -> ObjectsVisualizer(context)
            CLOTHES -> ClothesVisualizer(context)
            SEASONS -> SeasonsVisualizer(context)
            OCEAN_LIFE -> OceanLifeVisualizer(context)
            VEHICLES -> VehiclesVisualizer(context)
            SHAPES_COLORS -> ShapesColorsVisualizer(context)
            FOOD_DRINKS -> FoodDrinksVisualizer(context)

            CLASSIC_SPECTRUM -> ClassicSpectrumVisualizer(context)
            COLOR_GRID -> ColorGridVisualizer(context)
            CIRCULAR_SPECTRUM -> CircularSpectrumVisualizer(context)
            VU_METERS -> VUMetersVisualizer(context)
            TUNNEL_WAVE -> TunnelWaveVisualizer(context)
        }
    }
}
