package com.bardia.visualizer.visualizers

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF

/**
 * A 3x3 grid of cells, each pulsing to a different part of the music and
 * cycling smoothly through rainbow colors - like a playful, colorful
 * "stock ticker" board but happy and multicolored instead of red/green,
 * with the color's Persian name labeled on each cell.
 */
class ColorGridVisualizer(context: Context) : BaseVisualizer(context) {

    private data class Cell(val hueOffset: Float, val band: Int, val phase: Float)

    // band: 0 = bass, 1 = mid, 2 = treble - spread across the grid for variety
    private val cells = listOf(
        Cell(0f, 0, 0.2f), Cell(40f, 1, 1.1f), Cell(80f, 2, 0.6f),
        Cell(140f, 2, 1.8f), Cell(180f, 0, 0.4f), Cell(220f, 1, 2.2f),
        Cell(260f, 1, 0.9f), Cell(300f, 2, 1.5f), Cell(330f, 0, 2.6f)
    )

    private var globalHue = 0f
    private val energies = FloatArray(9)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; isFakeBoldText = true }

    private val colorNames = listOf(
        0f to "قرمز", 20f to "نارنجی", 45f to "زرد", 75f to "سبز‌روشن",
        110f to "سبز", 165f to "فیروزه‌ای", 200f to "آبی‌روشن", 230f to "آبی",
        265f to "بنفش", 300f to "صورتی", 330f to "سرخابی", 360f to "قرمز"
    )

    private fun nameForHue(hue: Float): String {
        val h = ((hue % 360f) + 360f) % 360f
        for (i in 0 until colorNames.size - 1) {
            val (a, name) = colorNames[i]
            val (b, _) = colorNames[i + 1]
            if (h in a..b) return name
        }
        return colorNames.last().second
    }

    override fun onTick(deltaSeconds: Float) {
        globalHue = (globalHue + deltaSeconds * (18f + treble() * 30f)) % 360f
        val b = bass(); val m = mid(); val t = treble()
        for (i in cells.indices) {
            val cell = cells[i]
            val bandVal = when (cell.band) { 0 -> b; 1 -> m; else -> t }
            val pulse = kotlin.math.sin(time * (2.4f + bandVal * 5f) + cell.phase) * 0.5f + 0.5f
            val target = (0.35f + bandVal * 0.55f + pulse * 0.25f).coerceIn(0.2f, 1f)
            energies[i] += (target - energies[i]) * (deltaSeconds * 10f).coerceAtMost(1f)
        }
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(if (isDarkTheme) Color.parseColor("#0A0A12") else Color.parseColor("#FAFAFA"))
        val w = width.toFloat(); val h = height.toFloat()
        val cols = 3; val rows = 3
        val cellW = w / cols; val cellH = h / rows
        val gap = kotlin.math.min(cellW, cellH) * 0.05f

        for (i in cells.indices) {
            val col = i % cols; val row = i / cols
            val cell = cells[i]
            val energy = energies[i]
            val hue = (globalHue + cell.hueOffset) % 360f
            val pad = gap + (1f - energy) * cellW * 0.09f

            val left = col * cellW + pad
            val top = row * cellH + pad
            val right = (col + 1) * cellW - pad
            val bottom = (row + 1) * cellH - pad

            paint.color = Color.HSVToColor(floatArrayOf(hue, 0.75f, (0.65f + energy * 0.35f).coerceIn(0f, 1f)))
            canvas.drawRoundRect(RectF(left, top, right, bottom), 28f, 28f, paint)

            val name = nameForHue(hue)
            val brightness = 0.65f + energy * 0.35f
            labelPaint.color = if (brightness > 0.72f) Color.parseColor("#20222A") else Color.WHITE
            labelPaint.textSize = cellW * 0.11f
            canvas.drawText(name, (left + right) / 2f, (top + bottom) / 2f + labelPaint.textSize * 0.35f, labelPaint)
        }
    }
}
