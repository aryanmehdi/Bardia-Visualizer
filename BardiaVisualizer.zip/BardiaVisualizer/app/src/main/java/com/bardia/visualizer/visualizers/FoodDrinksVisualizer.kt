package com.bardia.visualizer.visualizers

import android.content.Context

class FoodDrinksVisualizer(context: Context) : EmojiBaseVisualizer(
    context,
    listOf(
        "\uD83C\uDF55" to "پیتزا", "\uD83C\uDF54" to "همبرگر", "\uD83C\uDF5F" to "سیب‌زمینی",
        "\uD83C\uDF2E" to "بوریتو", "\uD83C\uDF70" to "کیک", "\uD83C\uDF66" to "بستنی",
        "\uD83C\uDF69" to "دونات", "\uD83C\uDF6A" to "کلوچه", "\uD83E\uDD64" to "نوشیدنی",
        "\uD83E\uDDC1" to "کاپ‌کیک"
    ),
    lightBg = android.graphics.Color.parseColor("#FFF3E0"),
    darkBg = android.graphics.Color.parseColor("#241A0E")
)
