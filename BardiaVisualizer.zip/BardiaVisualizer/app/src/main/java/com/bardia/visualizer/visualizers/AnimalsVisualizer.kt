package com.bardia.visualizer.visualizers

import android.content.Context

class AnimalsVisualizer(context: Context) : EmojiBaseVisualizer(
    context,
    listOf(
        "\uD83D\uDC36" to "سگ", "\uD83D\uDC31" to "گربه", "\uD83E\uDD81" to "شیر",
        "\uD83D\uDC2F" to "ببر", "\uD83D\uDC18" to "فیل", "\uD83E\uDD92" to "زرافه",
        "\uD83D\uDC28" to "پاندا", "\uD83D\uDC30" to "خرگوش", "\uD83D\uDC38" to "قورباغه",
        "\uD83D\uDC0D" to "مار"
    )
)
