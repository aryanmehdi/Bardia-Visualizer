package com.bardia.visualizer.visualizers

import android.content.Context

class ClothesVisualizer(context: Context) : EmojiBaseVisualizer(
    context,
    listOf(
        "\uD83D\uDC55" to "تی‌شرت", "\uD83D\uDC56" to "شلوار", "\uD83D\uDC57" to "پیراهن",
        "\uD83E\uDDE6" to "کت", "\uD83D\uDC5F" to "کفش", "\uD83E\uDDE3" to "شال",
        "\uD83E\uDDE4" to "دستکش", "\uD83C\uDFBD" to "رکابی", "\uD83D\uDC52" to "کلاه",
        "\uD83E\uDD7F" to "جوراب"
    ),
    lightBg = android.graphics.Color.parseColor("#FFF0F6"),
    darkBg = android.graphics.Color.parseColor("#231420")
)
