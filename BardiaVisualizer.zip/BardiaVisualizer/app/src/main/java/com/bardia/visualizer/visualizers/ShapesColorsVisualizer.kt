package com.bardia.visualizer.visualizers

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.random.Random

/**
 * Shapes & colors are drawn natively (not with emoji glyphs) so every TV
 * renders them identically, regardless of which emoji font it ships.
 */
class ShapesColorsVisualizer(context: Context) : BaseVisualizer(context) {

    private enum class Shape { CIRCLE, SQUARE, TRIANGLE, STAR, DIAMOND, HEART }
    private data class Item(val shape: Shape, val color: Int, val name: String)
    private data class Sprite(var x: Float, var y: Float, var vx: Float, var vy: Float, var itemIndex: Int, var wobble: Float, var baseSize: Float)

    private val items = listOf(
        Item(Shape.CIRCLE, Color.parseColor("#E5342B"), "دایره قرمز"),
        Item(Shape.CIRCLE, Color.parseColor("#FF8A1E"), "دایره نارنجی"),
        Item(Shape.CIRCLE, Color.parseColor("#FFD400"), "دایره زرد"),
        Item(Shape.SQUARE, Color.parseColor("#33B24A"), "مربع سبز"),
        Item(Shape.SQUARE, Color.parseColor("#2E7BFF"), "مربع آبی"),
        Item(Shape.TRIANGLE, Color.parseColor("#9B4FE0"), "مثلث بنفش"),
        Item(Shape.STAR, Color.parseColor("#FFC93C"), "ستاره طلایی"),
        Item(Shape.DIAMOND, Color.parseColor("#FF5FA2"), "لوزی صورتی"),
        Item(Shape.HEART, Color.parseColor("#FF3B5C"), "قلب قرمز"),
        Item(Shape.SQUARE, Color.parseColor("#00C2C7"), "مربع فیروزه‌ای")
    )

    private val sprites = mutableListOf<Sprite>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; isFakeBoldText = true }
    private val cardBgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    private var featureIndex = 0
    private var featureTimer = 0f
    private var cardScale = 0f

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        sprites.clear()
        repeat(22) {
            sprites.add(
                Sprite(
                    Random.nextFloat() * w, Random.nextFloat() * h * 0.85f + h * 0.08f,
                    (Random.nextFloat() - 0.5f) * 220f, (Random.nextFloat() - 0.5f) * 180f,
                    Random.nextInt(items.size), Random.nextFloat() * 6.28f,
                    0.75f + Random.nextFloat() * 0.7f
                )
            )
        }
        featureIndex = Random.nextInt(items.size)
    }

    override fun onTick(deltaSeconds: Float) {
        val m = mid()
        for (s in sprites) {
            s.x += s.vx * (1f + m * 1.1f) * deltaSeconds
            s.y += s.vy * (1f + m * 1.1f) * deltaSeconds
            if (s.x < 70f || s.x > width - 70f) s.vx *= -1f
            if (s.y < 100f || s.y > height - 70f) s.vy *= -1f
            s.x = s.x.coerceIn(50f, (width - 50f).coerceAtLeast(51f))
            s.y = s.y.coerceIn(90f, (height - 50f).coerceAtLeast(91f))
        }
        featureTimer += deltaSeconds
        if (featureTimer >= 5f) {
            featureTimer = 0f
            featureIndex = (featureIndex + 1 + Random.nextInt(items.size - 1)) % items.size
            cardScale = 0.01f
        }
        if (cardScale in 0.01f..0.94f) cardScale += (1f - cardScale) * (deltaSeconds * 12f).coerceAtMost(1f)
        else if (cardScale > 0f) cardScale = 1f
    }

    private fun drawShape(canvas: Canvas, shape: Shape, cx: Float, cy: Float, size: Float, color: Int, rotation: Float) {
        paint.color = color
        canvas.save()
        canvas.translate(cx, cy)
        canvas.rotate(rotation)
        when (shape) {
            Shape.CIRCLE -> canvas.drawCircle(0f, 0f, size / 2, paint)
            Shape.SQUARE -> canvas.drawRoundRect(RectF(-size / 2, -size / 2, size / 2, size / 2), size * 0.15f, size * 0.15f, paint)
            Shape.TRIANGLE -> {
                path.reset()
                path.moveTo(0f, -size / 2)
                path.lineTo(size / 2, size / 2)
                path.lineTo(-size / 2, size / 2)
                path.close()
                canvas.drawPath(path, paint)
            }
            Shape.DIAMOND -> {
                path.reset()
                path.moveTo(0f, -size / 2)
                path.lineTo(size / 2, 0f)
                path.lineTo(0f, size / 2)
                path.lineTo(-size / 2, 0f)
                path.close()
                canvas.drawPath(path, paint)
            }
            Shape.STAR -> {
                path.reset()
                val outer = size / 2; val inner = outer * 0.42f
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) outer else inner
                    val ang = Math.toRadians((i * 36f - 90f).toDouble())
                    val px = kotlin.math.cos(ang).toFloat() * r
                    val py = kotlin.math.sin(ang).toFloat() * r
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                canvas.drawPath(path, paint)
            }
            Shape.HEART -> {
                val s = size / 2
                path.reset()
                path.moveTo(0f, s * 0.35f)
                path.cubicTo(-s * 1.1f, -s * 0.5f, -s * 0.4f, -s * 1.1f, 0f, -s * 0.25f)
                path.cubicTo(s * 0.4f, -s * 1.1f, s * 1.1f, -s * 0.5f, 0f, s * 0.35f)
                path.close()
                canvas.drawPath(path, paint)
            }
        }
        canvas.restore()
    }

    override fun onDraw(canvas: Canvas) {
        drawLivelyBackground(canvas, Color.parseColor("#111111"), Color.WHITE)
        val b = bass(); val amp = amplitude()

        for (s in sprites) {
            val item = items[s.itemIndex]
            val size = 90f * s.baseSize * (1f + b * 0.4f + 0.1f * kotlin.math.sin(time * 5f + s.wobble))
            val rot = kotlin.math.sin(time * 2f + s.wobble) * (14f + amp * 24f)
            drawShape(canvas, item.shape, s.x, s.y, size, item.color, rot)
        }

        if (cardScale > 0.02f) {
            val item = items[featureIndex]
            val cx = width / 2f; val cy = height / 2f
            val panelW = 620f * cardScale
            val panelH = 460f * cardScale
            cardBgPaint.color = if (isDarkTheme) Color.argb(225, 25, 25, 25) else Color.argb(235, 245, 245, 245)
            canvas.drawRoundRect(RectF(cx - panelW / 2, cy - panelH / 2, cx + panelW / 2, cy + panelH / 2), 50f, 50f, cardBgPaint)

            drawShape(canvas, item.shape, cx, cy - panelH * 0.08f, 200f * cardScale, item.color, 0f)

            labelPaint.textSize = 74f * cardScale
            labelPaint.color = if (isDarkTheme) Color.WHITE else Color.parseColor("#2A2A2A")
            canvas.drawText(item.name, cx, cy + panelH * 0.34f, labelPaint)
        }
    }
}
