package com.bardia.visualizer.visualizers

import android.content.Context

class ShapesColorsVisualizer(context: Context) : EmojiBaseVisualizer(
    context,
    listOf(
        "\uD83D\uDD34" to "دایره قرمز", "\uD83D\uDFE0" to "دایره نارنجی", "\uD83D\uDFE1" to "دایره زرد",
        "\uD83D\uDFE2" to "دایره سبز", "\uD83D\uDD35" to "دایره آبی", "\uD83D\uDFE3" to "دایره بنفش",
        "\u2B1C" to "مربع سفید", "\u2B1B" to "مربع مشکی", "\uD83D\uDD36" to "لوزی",
        "\u2B50" to "ستاره"
    ),
    lightBg = android.graphics.Color.parseColor("#FFFFFF"),
    darkBg = android.graphics.Color.parseColor("#111111")
)
