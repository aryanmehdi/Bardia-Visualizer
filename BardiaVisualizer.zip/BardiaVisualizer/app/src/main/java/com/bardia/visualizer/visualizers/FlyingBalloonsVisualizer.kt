package com.bardia.visualizer.visualizers

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import kotlin.random.Random

class FlyingBalloonsVisualizer(context: Context) : BaseVisualizer(context) {

    private data class Balloon(var x: Float, var y: Float, var size: Float, var speed: Float, var hue: Float, var phase: Float)

    private val balloons = mutableListOf<Balloon>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 4f; style = Paint.Style.STROKE }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        balloons.clear()
        repeat(10) { spawn(Random.nextFloat() * h) }
    }

    private fun spawn(startY: Float = height + 120f) {
        if (width == 0) return
        balloons.add(
            Balloon(
                Random.nextFloat() * width, startY,
                60f + Random.nextFloat() * 50f,
                50f + Random.nextFloat() * 40f,
                Random.nextFloat() * 360f,
                Random.nextFloat() * 6.28f
            )
        )
    }

    private var spawnTimer = 0f

    override fun onTick(deltaSeconds: Float) {
        val boost = if (isBeat()) 260f else 0f
        for (bl in balloons) {
            bl.y -= (bl.speed + bass() * 150f + boost) * deltaSeconds
            bl.x += kotlin.math.sin(time * 1.1f + bl.phase) * 24f * deltaSeconds
        }
        balloons.removeAll { it.y < -150f }
        spawnTimer += deltaSeconds
        if (spawnTimer > 0.8f && balloons.size < 16) {
            spawnTimer = 0f
            spawn()
        }
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(if (isDarkTheme) Color.parseColor("#1A1030") else Color.parseColor("#FFF0F6"))
        stringPaint.color = if (isDarkTheme) Color.parseColor("#88FFFFFF") else Color.parseColor("#886B4B4B")

        for (bl in balloons) {
            val pulse = 1f + amplitude() * 0.2f
            val w = bl.size * pulse
            val h = bl.size * 1.25f * pulse
            paint.color = Color.HSVToColor(floatArrayOf((bl.hue + time * 15f) % 360f, 0.7f, 1f))

            canvas.save()
            canvas.translate(bl.x, bl.y)
            canvas.drawOval(-w / 2, -h / 2, w / 2, h / 2, paint)
            // highlight
            paint.color = Color.argb(120, 255, 255, 255)
            canvas.drawOval(-w / 4, -h / 3, 0f, -h / 6, paint)
            canvas.restore()

            val path = Path().apply {
                moveTo(bl.x, bl.y + h / 2)
                lineTo(bl.x, bl.y + h / 2 + 70f)
            }
            canvas.drawPath(path, stringPaint)
        }
    }
}
