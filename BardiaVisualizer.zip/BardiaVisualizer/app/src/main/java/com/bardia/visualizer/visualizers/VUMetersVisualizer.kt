package com.bardia.visualizer.visualizers

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF

/**
 * Classic dual analog-style VU meters (like old stereo amplifiers /
 * Winamp's VU meter skin), with green/yellow/red zones and peak markers.
 */
class VUMetersVisualizer(context: Context) : BaseVisualizer(context) {

    private var leftLevel = 0f
    private var rightLevel = 0f
    private var leftPeak = 0f
    private var rightPeak = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; isFakeBoldText = true; textSize = 44f }

    override fun onTick(deltaSeconds: Float) {
        val targetL = (bass() * 0.75f + amplitude() * 0.5f).coerceIn(0f, 1f)
        val targetR = (treble() * 0.75f + amplitude() * 0.5f).coerceIn(0f, 1f)
        leftLevel += (targetL - leftLevel) * (deltaSeconds * 16f).coerceAtMost(1f)
        rightLevel += (targetR - rightLevel) * (deltaSeconds * 16f).coerceAtMost(1f)
        leftPeak = if (leftLevel >= leftPeak) leftLevel else (leftPeak - deltaSeconds * 0.4f).coerceAtLeast(leftLevel)
        rightPeak = if (rightLevel >= rightPeak) rightLevel else (rightPeak - deltaSeconds * 0.4f).coerceAtLeast(rightLevel)
    }

    private fun drawMeter(canvas: Canvas, cx: Float, top: Float, w: Float, h: Float, level: Float, peak: Float, label: String) {
        val bg = if (isDarkTheme) Color.parseColor("#1C1810") else Color.parseColor("#F0EAD8")
        paint.color = bg
        val rect = RectF(cx - w / 2, top, cx + w / 2, top + h)
        canvas.drawRoundRect(rect, 18f, 18f, paint)

        val segCount = 24
        val segH = (h - 20f) / segCount
        val lit = (level * segCount).toInt()
        for (seg in 0 until segCount) {
            val frac = seg / segCount.toFloat()
            val segTop = top + h - 10f - (seg + 1) * segH
            val color = when {
                frac < 0.6f -> Color.rgb(60, 210, 90)
                frac < 0.82f -> Color.rgb(230, 200, 40)
                else -> Color.rgb(230, 50, 50)
            }
            paint.color = color
            paint.alpha = if (seg < lit) 255 else if (isDarkTheme) 30 else 50
            canvas.drawRect(cx - w / 2 + 10f, segTop + 3f, cx + w / 2 - 10f, segTop + segH - 3f, paint)
        }
        val peakY = top + h - 10f - peak * (h - 20f)
        paint.color = Color.WHITE
        paint.alpha = 255
        canvas.drawRect(cx - w / 2 + 6f, peakY - 4f, cx + w / 2 - 6f, peakY, paint)

        labelPaint.color = if (isDarkTheme) Color.WHITE else Color.parseColor("#333333")
        canvas.drawText(label, cx, top + h + 50f, labelPaint)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(if (isDarkTheme) Color.parseColor("#0D0D0D") else Color.parseColor("#FAFAF5"))
        val w = width.toFloat(); val h = height.toFloat()
        val meterW = w * 0.22f
        val meterH = h * 0.72f
        val top = h * 0.12f
        drawMeter(canvas, w * 0.32f, top, meterW, meterH, leftLevel, leftPeak, "چپ")
        drawMeter(canvas, w * 0.68f, top, meterW, meterH, rightLevel, rightPeak, "راست")
    }
}
