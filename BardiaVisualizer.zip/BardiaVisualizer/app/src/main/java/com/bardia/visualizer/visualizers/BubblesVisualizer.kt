package com.bardia.visualizer.visualizers

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.random.Random

class BubblesVisualizer(context: Context) : BaseVisualizer(context) {

    private data class Bubble(
        var x: Float, var y: Float, var baseRadius: Float,
        var speed: Float, var hue: Float, var wobblePhase: Float,
        var spinDir: Float, var hasFace: Boolean
    )

    private val bubbles = mutableListOf<Bubble>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var lastSpawn = 0f

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        bubbles.clear()
        repeat(16) { spawnBubble(Random.nextFloat() * h) }
    }

    private fun spawnBubble(startY: Float = height.toFloat() + 40f) {
        if (width == 0 || height == 0) return
        bubbles.add(
            Bubble(
                x = Random.nextFloat() * width,
                y = startY,
                baseRadius = 26f + Random.nextFloat() * 80f,
                speed = 70f + Random.nextFloat() * 100f,
                hue = Random.nextFloat() * 360f,
                wobblePhase = Random.nextFloat() * 6.28f,
                spinDir = if (Random.nextBoolean()) 1f else -1f,
                hasFace = Random.nextFloat() < 0.3f
            )
        )
    }

    override fun onTick(deltaSeconds: Float) {
        val b = bass(); val amp = amplitude(); val beat = isBeat()
        for (bub in bubbles) {
            val crazy = 1f + amp * 1.4f
            bub.y -= (bub.speed + b * 300f) * deltaSeconds * crazy
            bub.x += kotlin.math.sin(time * (2.2f + amp * 4f) * bub.spinDir + bub.wobblePhase) * (30f + amp * 90f) * deltaSeconds
            bub.hue = (bub.hue + deltaSeconds * (25f + amp * 90f)) % 360f
        }
        bubbles.removeAll { it.y < -120f || it.x < -150f || it.x > width + 150f }

        lastSpawn += deltaSeconds
        val spawnInterval = if (beat) 0.03f else (0.28f - amp * 0.15f).coerceAtLeast(0.06f)
        if (lastSpawn > spawnInterval && bubbles.size < 55) {
            lastSpawn = 0f
            spawnBubble()
            if (beat && bass() > 0.4f) spawnBubble()
        }
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(if (isDarkTheme) Color.parseColor("#101830") else Color.parseColor("#DFF2FF"))
        val b = bass()
        for (bub in bubbles) {
            val pulse = 1f + b * 0.55f + 0.12f * kotlin.math.sin(time * 6f + bub.wobblePhase)
            val r = bub.baseRadius * pulse
            val color = Color.HSVToColor(floatArrayOf(bub.hue, 0.68f, 1f))
            paint.shader = RadialGradient(
                bub.x - r * 0.3f, bub.y - r * 0.3f, r * 1.3f,
                Color.WHITE, color, Shader.TileMode.CLAMP
            )
            paint.alpha = 220
            canvas.drawCircle(bub.x, bub.y, r, paint)
            paint.shader = null

            if (bub.hasFace && r > 30f) {
                paint.color = Color.argb(200, 40, 40, 40)
                val eyeOffset = r * 0.32f
                val eyeR = r * 0.09f
                canvas.drawCircle(bub.x - eyeOffset, bub.y - r * 0.1f, eyeR, paint)
                canvas.drawCircle(bub.x + eyeOffset, bub.y - r * 0.1f, eyeR, paint)
                val smileOpen = 0.3f + b * 0.5f
                canvas.drawArc(
                    bub.x - r * 0.3f, bub.y + r * 0.02f, bub.x + r * 0.3f, bub.y + r * 0.02f + r * 0.35f * smileOpen,
                    0f, 180f, false, paint
                )
            }
        }
    }
}
