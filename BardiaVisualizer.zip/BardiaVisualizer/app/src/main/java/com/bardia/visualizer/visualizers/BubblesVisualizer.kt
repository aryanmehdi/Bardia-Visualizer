package com.bardia.visualizer.visualizers

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.random.Random

class BubblesVisualizer(context: Context) : BaseVisualizer(context) {

    private data class Bubble(
        var x: Float, var y: Float, var baseRadius: Float,
        var speed: Float, var hue: Float, var wobblePhase: Float
    )

    private val bubbles = mutableListOf<Bubble>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var lastSpawn = 0f

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        bubbles.clear()
        repeat(14) { spawnBubble(Random.nextFloat() * h) }
    }

    private fun spawnBubble(startY: Float = height.toFloat() + 40f) {
        if (width == 0 || height == 0) return
        bubbles.add(
            Bubble(
                x = Random.nextFloat() * width,
                y = startY,
                baseRadius = 30f + Random.nextFloat() * 70f,
                speed = 40f + Random.nextFloat() * 60f,
                hue = Random.nextFloat() * 360f,
                wobblePhase = Random.nextFloat() * 6.28f
            )
        )
    }

    override fun onTick(deltaSeconds: Float) {
        val b = bass(); val amp = amplitude()
        for (bub in bubbles) {
            bub.y -= (bub.speed + b * 220f) * deltaSeconds
            bub.x += kotlin.math.sin(time * 1.3f + bub.wobblePhase) * 18f * deltaSeconds
            bub.hue = (bub.hue + deltaSeconds * (10f + amp * 30f)) % 360f
        }
        bubbles.removeAll { it.y < -100f }

        lastSpawn += deltaSeconds
        val spawnInterval = if (isBeat()) 0.05f else 0.4f
        if (lastSpawn > spawnInterval && bubbles.size < 40) {
            lastSpawn = 0f
            spawnBubble()
        }
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(if (isDarkTheme) Color.parseColor("#101830") else Color.parseColor("#DFF2FF"))
        val b = bass()
        for (bub in bubbles) {
            val pulse = 1f + b * 0.35f + 0.05f * kotlin.math.sin(time * 4f + bub.wobblePhase)
            val r = bub.baseRadius * pulse
            val color = Color.HSVToColor(floatArrayOf(bub.hue, 0.65f, 1f))
            paint.shader = RadialGradient(
                bub.x - r * 0.3f, bub.y - r * 0.3f, r * 1.3f,
                Color.WHITE, color, Shader.TileMode.CLAMP
            )
            paint.alpha = 210
            canvas.drawCircle(bub.x, bub.y, r, paint)
        }
        paint.shader = null
    }
}
