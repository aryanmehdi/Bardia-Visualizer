package com.bardia.visualizer.visualizers

import android.content.Context

class FruitsVisualizer(context: Context) : EmojiBaseVisualizer(
    context,
    listOf(
        "\uD83C\uDF4E" to "سیب", "\uD83C\uDF4C" to "موز", "\uD83C\uDF47" to "انگور",
        "\uD83C\uDF49" to "هندوانه", "\uD83C\uDF53" to "توت‌فرنگی", "\uD83C\uDF4A" to "پرتقال",
        "\uD83C\uDF51" to "هلو", "\uD83C\uDF4D" to "آناناس", "\uD83C\uDF52" to "گیلاس",
        "\uD83E\uDD5D" to "کیوی"
    ),
    lightBg = android.graphics.Color.parseColor("#FFF0E8"),
    darkBg = android.graphics.Color.parseColor("#241614")
)
