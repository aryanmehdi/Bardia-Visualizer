package com.bardia.visualizer.visualizers

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import kotlin.math.hypot

class PulseRingsVisualizer(context: Context) : BaseVisualizer(context) {

    private data class Ring(var radius: Float, var hue: Float, var alpha: Int)

    private val rings = mutableListOf<Ring>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private var hueBase = 0f
    private var spawnTimer = 0f

    override fun onTick(deltaSeconds: Float) {
        hueBase = (hueBase + deltaSeconds * 40f) % 360f
        spawnTimer += deltaSeconds
        val interval = if (isBeat()) 0f else 0.4f - mid() * 0.3f
        if (spawnTimer >= interval) {
            spawnTimer = 0f
            rings.add(Ring(20f, hueBase, 255))
            if (isBeat() && bass() > 0.45f) rings.add(Ring(20f, (hueBase + 40f) % 360f, 255))
        }
        val maxR = hypot(width.toFloat(), height.toFloat()) / 2f + 40f
        for (r in rings) {
            r.radius += (260f + bass() * 420f) * deltaSeconds
            r.alpha = (255 * (1f - r.radius / maxR)).toInt().coerceIn(0, 255)
        }
        rings.removeAll { it.radius > maxR }
    }

    override fun onDraw(canvas: Canvas) {
        drawLivelyBackground(canvas, Color.parseColor("#0B0B1E"), Color.parseColor("#FFF3E0"))
        val cx = width / 2f; val cy = height / 2f
        for (r in rings) {
            paint.strokeWidth = 14f + bass() * 20f
            paint.color = Color.HSVToColor(r.alpha, floatArrayOf(r.hue, 0.75f, 1f))
            canvas.drawCircle(cx, cy, r.radius, paint)
        }
        // center pulsing core
        paint.style = Paint.Style.FILL
        paint.color = Color.HSVToColor(floatArrayOf(hueBase, 0.6f, 1f))
        canvas.drawCircle(cx, cy, 40f + bass() * 60f + amplitude() * 20f, paint)
        paint.style = Paint.Style.STROKE
    }
}
