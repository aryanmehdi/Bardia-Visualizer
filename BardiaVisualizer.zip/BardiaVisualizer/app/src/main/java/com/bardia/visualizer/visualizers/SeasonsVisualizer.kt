package com.bardia.visualizer.visualizers

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.random.Random

/**
 * Cycles through the four seasons every ~7 seconds, each with its own
 * weather that reacts to the music: gentle spring rain + blooming greenery,
 * a pulsing summer sun, autumn wind blowing falling leaves, and drifting
 * winter snow. A big Persian label announces each season as it begins.
 */
class SeasonsVisualizer(context: Context) : BaseVisualizer(context) {

    private enum class Season(val label: String) {
        SPRING("بهار \uD83C\uDF31"), SUMMER("تابستان \u2600\uFE0F"), AUTUMN("پاییز \uD83C\uDF42"), WINTER("زمستان \u2744\uFE0F")
    }

    private data class Drop(var x: Float, var y: Float, var speed: Float, var len: Float)
    private data class Flake(var x: Float, var y: Float, var speed: Float, var drift: Float, var size: Float)
    private data class Leaf(var x: Float, var y: Float, var speed: Float, var phase: Float, var hue: Float)
    private data class Sprout(val x: Float, var growth: Float, val hue: Float)

    private val seasonDurationSec = 7f
    private var seasonTimer = 0f
    private var seasonIndex = 0
    private var labelAlpha = 1f

    private val drops = mutableListOf<Drop>()
    private val flakes = mutableListOf<Flake>()
    private val leaves = mutableListOf<Leaf>()
    private val sprouts = mutableListOf<Sprout>()

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
        textSize = 84f
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        drops.clear(); repeat(50) { drops.add(Drop(Random.nextFloat() * w, Random.nextFloat() * h, 400f + Random.nextFloat() * 300f, 20f + Random.nextFloat() * 20f)) }
        flakes.clear(); repeat(60) { flakes.add(Flake(Random.nextFloat() * w, Random.nextFloat() * h, 40f + Random.nextFloat() * 60f, Random.nextFloat() * 6.28f, 5f + Random.nextFloat() * 8f)) }
        leaves.clear(); repeat(30) { leaves.add(Leaf(Random.nextFloat() * w, Random.nextFloat() * h, 60f + Random.nextFloat() * 80f, Random.nextFloat() * 6.28f, 25f + Random.nextFloat() * 40f)) }
        sprouts.clear(); repeat(9) { sprouts.add(Sprout((it + 0.5f) * w / 9f, 0f, 90f + Random.nextFloat() * 60f)) }
    }

    private fun currentSeason() = Season.values()[seasonIndex]

    override fun onTick(deltaSeconds: Float) {
        seasonTimer += deltaSeconds
        labelAlpha = (1f - seasonTimer / 2.2f).coerceIn(0f, 1f)
        if (seasonTimer >= seasonDurationSec) {
            seasonTimer = 0f
            seasonIndex = (seasonIndex + 1) % Season.values().size
            labelAlpha = 1f
        }

        val b = bass(); val m = mid(); val t = treble()
        when (currentSeason()) {
            Season.SPRING -> {
                for (d in drops) {
                    d.y += (d.speed * 1.1f + b * 420f) * deltaSeconds
                    if (d.y > height) { d.y = -20f; d.x = Random.nextFloat() * width }
                }
                for (s in sprouts) {
                    s.growth = (s.growth + (0.6f + m * 2.2f) * deltaSeconds * 70f).coerceAtMost(height * 0.32f)
                }
            }
            Season.SUMMER -> { /* sun pulses via bass directly in onDraw */ }
            Season.AUTUMN -> {
                for (l in leaves) {
                    l.y += (l.speed * 1.2f + m * 340f) * deltaSeconds
                    l.x += kotlin.math.sin(time * 3f + l.phase) * (60f + t * 100f) * deltaSeconds
                    if (l.y > height) { l.y = -30f; l.x = Random.nextFloat() * width }
                }
            }
            Season.WINTER -> {
                for (f in flakes) {
                    f.y += (f.speed * 0.9f + amplitude() * 220f) * deltaSeconds
                    f.x += kotlin.math.sin(time * 2f + f.drift) * 55f * deltaSeconds
                    if (f.y > height) { f.y = -20f; f.x = Random.nextFloat() * width }
                }
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        val season = currentSeason()
        val bgTop: Int; val bgBottom: Int
        when (season) {
            Season.SPRING -> { bgTop = Color.parseColor(if (isDarkTheme) "#1B2E1C" else "#DFF6DA"); bgBottom = Color.parseColor(if (isDarkTheme) "#12201A" else "#C9F0C0") }
            Season.SUMMER -> { bgTop = Color.parseColor(if (isDarkTheme) "#123055" else "#8FD8FF"); bgBottom = Color.parseColor(if (isDarkTheme) "#0A1E38" else "#C9F0FF") }
            Season.AUTUMN -> { bgTop = Color.parseColor(if (isDarkTheme) "#3A2412" else "#FFE0B0"); bgBottom = Color.parseColor(if (isDarkTheme) "#241708" else "#FFC98A") }
            Season.WINTER -> { bgTop = Color.parseColor(if (isDarkTheme) "#1A2233" else "#E8F3FF"); bgBottom = Color.parseColor(if (isDarkTheme) "#0F1620" else "#CDE6FF") }
        }
        paint.shader = android.graphics.LinearGradient(0f, 0f, 0f, height.toFloat(), bgTop, bgBottom, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        paint.shader = null

        when (season) {
            Season.SPRING -> drawSpring(canvas)
            Season.SUMMER -> drawSummer(canvas)
            Season.AUTUMN -> drawAutumn(canvas)
            Season.WINTER -> drawWinter(canvas)
        }

        if (labelAlpha > 0f) {
            labelPaint.color = Color.argb((labelAlpha * 255).toInt().coerceIn(0, 255), 255, 255, 255)
            labelPaint.textSize = 90f + bass() * 20f
            canvas.drawText(currentSeason().label, width / 2f, height * 0.18f, labelPaint)
        }
    }

    private fun drawSpring(canvas: Canvas) {
        paint.color = Color.argb(160, 140, 200, 255)
        paint.strokeWidth = 4f
        for (d in drops) canvas.drawLine(d.x, d.y, d.x - 4f, d.y + d.len, paint)

        val groundY = height * 0.9f
        for (s in sprouts) {
            paint.color = Color.HSVToColor(floatArrayOf(100f, 0.5f, 0.6f))
            paint.strokeWidth = 8f
            canvas.drawLine(s.x, groundY, s.x, groundY - s.growth, paint)
            paint.color = Color.HSVToColor(floatArrayOf(s.hue, 0.6f, 0.9f))
            canvas.drawCircle(s.x, groundY - s.growth, 16f + bass() * 10f, paint)
        }
    }

    private fun drawSummer(canvas: Canvas) {
        val cx = width * 0.5f; val cy = height * 0.42f
        val r = 170f + bass() * 90f + amplitude() * 40f
        paint.shader = RadialGradient(cx, cy, r * 2.4f, Color.parseColor("#FFE072"), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, r * 2.4f, paint)
        paint.shader = null
        paint.color = Color.parseColor("#FFC93C")
        canvas.drawCircle(cx, cy, r, paint)
        paint.strokeWidth = 12f
        val rays = 16
        for (i in 0 until rays) {
            val ang = Math.toRadians((i * 360f / rays + time * 70f).toDouble())
            val len = r * (1.55f + treble() * 0.7f)
            canvas.drawLine(
                cx + kotlin.math.cos(ang).toFloat() * r * 1.12f, cy + kotlin.math.sin(ang).toFloat() * r * 1.12f,
                cx + kotlin.math.cos(ang).toFloat() * len, cy + kotlin.math.sin(ang).toFloat() * len, paint
            )
        }
    }

    private fun drawAutumn(canvas: Canvas) {
        for (l in leaves) {
            paint.color = Color.HSVToColor(floatArrayOf(l.hue, 0.75f, 0.95f))
            canvas.save()
            canvas.translate(l.x, l.y)
            canvas.rotate(time * 60f + l.phase * 30f)
            canvas.drawOval(-14f, -9f, 14f, 9f, paint)
            canvas.restore()
        }
    }

    private fun drawWinter(canvas: Canvas) {
        paint.color = Color.WHITE
        for (f in flakes) canvas.drawCircle(f.x, f.y, f.size, paint)
        paint.color = Color.argb(255, 235, 245, 255)
        canvas.drawRect(0f, height * 0.92f, width.toFloat(), height.toFloat(), paint)
    }
}
