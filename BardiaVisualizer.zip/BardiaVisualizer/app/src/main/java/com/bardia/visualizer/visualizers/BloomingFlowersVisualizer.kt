package com.bardia.visualizer.visualizers

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import kotlin.random.Random

class BloomingFlowersVisualizer(context: Context) : BaseVisualizer(context) {

    private data class Flower(val x: Float, val y: Float, val petals: Int, val baseSize: Float, val hue: Float, val phase: Float)

    private val flowers = mutableListOf<Flower>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        flowers.clear()
        val cols = 5
        for (i in 0 until cols) {
            val fx = (i + 0.5f) * w / cols + Random.nextFloat() * 40f - 20f
            val fy = h * (0.55f + Random.nextFloat() * 0.35f)
            flowers.add(Flower(fx, fy, 5 + Random.nextInt(3), 50f + Random.nextFloat() * 40f, Random.nextFloat() * 360f, Random.nextFloat() * 6.28f))
        }
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(if (isDarkTheme) Color.parseColor("#142312") else Color.parseColor("#E9FFE3"))
        val b = bass(); val m = mid()

        for (f in flowers) {
            val open = 0.5f + 0.5f * kotlin.math.sin(time * 1.5f + f.phase) * 0.5f + b * 0.5f
            val bloom = (0.55f + open * 0.55f).coerceIn(0.3f, 1.4f)
            val size = f.baseSize * bloom

            // stem
            paint.color = Color.parseColor(if (isDarkTheme) "#3F7A3A" else "#5FA85A")
            paint.strokeWidth = 10f
            canvas.drawLine(f.x, f.y, f.x, f.y + 160f, paint)

            // petals
            val hue = (f.hue + time * 12f) % 360f
            paint.color = Color.HSVToColor(floatArrayOf(hue, 0.6f, 1f))
            for (p in 0 until f.petals) {
                val angle = (p * 360f / f.petals) + time * 20f
                val rad = Math.toRadians(angle.toDouble())
                val px = f.x + kotlin.math.cos(rad).toFloat() * size * 0.55f
                val py = f.y + kotlin.math.sin(rad).toFloat() * size * 0.55f
                canvas.drawCircle(px, py, size * 0.42f, paint)
            }
            // center
            paint.color = Color.HSVToColor(floatArrayOf((hue + 180) % 360f, 0.5f, 1f))
            canvas.drawCircle(f.x, f.y, size * (0.28f + m * 0.15f), paint)
        }
    }
}
