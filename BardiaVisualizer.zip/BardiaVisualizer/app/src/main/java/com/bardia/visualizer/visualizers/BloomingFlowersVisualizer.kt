package com.bardia.visualizer.visualizers

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import kotlin.random.Random

class BloomingFlowersVisualizer(context: Context) : BaseVisualizer(context) {

    private data class Flower(val x: Float, val y: Float, val petals: Int, val baseSize: Float, val hue: Float, val phase: Float)
    private data class Butterfly(var x: Float, var y: Float, val hue: Float, val phase: Float, val speed: Float)
    private data class Dot(val x: Float, val y: Float, var eaten: Boolean)

    private val flowers = mutableListOf<Flower>()
    private val butterflies = mutableListOf<Butterfly>()
    private val dots = mutableListOf<Dot>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    // Pac-man wandering along a simple horizontal patrol path, eating dots as he goes
    private var pacX = 0f
    private var pacY = 0f
    private var pacDir = 1f
    private var mouthPhase = 0f

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        flowers.clear()
        val cols = 6
        for (i in 0 until cols) {
            val fx = (i + 0.5f) * w / cols + Random.nextFloat() * 30f - 15f
            val fy = h * (0.6f + Random.nextFloat() * 0.3f)
            flowers.add(Flower(fx, fy, 5 + Random.nextInt(4), 45f + Random.nextFloat() * 40f, Random.nextFloat() * 360f, Random.nextFloat() * 6.28f))
        }
        butterflies.clear()
        repeat(4) {
            butterflies.add(Butterfly(Random.nextFloat() * w, h * (0.15f + Random.nextFloat() * 0.3f), Random.nextFloat() * 360f, Random.nextFloat() * 6.28f, 60f + Random.nextFloat() * 60f))
        }
        dots.clear()
        val dotY = h * 0.85f
        var dx = 40f
        while (dx < w - 40f) {
            dots.add(Dot(dx, dotY, false))
            dx += 70f
        }
        pacX = 0f
        pacY = dotY
    }

    override fun onTick(deltaSeconds: Float) {
        val b = bass(); val m = mid(); val amp = amplitude()
        mouthPhase += deltaSeconds * (6f + amp * 14f)

        pacX += pacDir * (140f + m * 220f) * deltaSeconds
        if (pacX > width + 30f) { pacDir = -1f; pacX = width + 30f }
        if (pacX < -30f) { pacDir = 1f; pacX = -30f }
        for (d in dots) {
            if (!d.eaten && kotlin.math.abs(d.x - pacX) < 26f) d.eaten = true
        }
        if (dots.all { it.eaten }) dots.forEach { it.eaten = false }

        for (bf in butterflies) {
            bf.x += kotlin.math.cos(time * 0.8f + bf.phase) * bf.speed * deltaSeconds
            bf.y += kotlin.math.sin(time * 1.6f + bf.phase) * 40f * deltaSeconds
            if (bf.x < -40f) bf.x = width + 40f
            if (bf.x > width + 40f) bf.x = -40f
        }
    }

    override fun onDraw(canvas: Canvas) {
        drawLivelyBackground(canvas, Color.parseColor("#142312"), Color.parseColor("#E9FFE3"))
        val b = bass(); val m = mid()

        for (f in flowers) {
            val open = 0.5f + 0.5f * kotlin.math.sin(time * 1.5f + f.phase) * 0.5f + b * 0.5f
            val bloom = (0.55f + open * 0.55f).coerceIn(0.3f, 1.4f)
            val size = f.baseSize * bloom

            paint.color = Color.parseColor(if (isDarkTheme) "#3F7A3A" else "#5FA85A")
            paint.strokeWidth = 10f
            canvas.drawLine(f.x, f.y, f.x, f.y + 140f, paint)

            val hue = (f.hue + time * 12f) % 360f
            paint.color = Color.HSVToColor(floatArrayOf(hue, 0.6f, 1f))
            for (p in 0 until f.petals) {
                val angle = (p * 360f / f.petals) + time * 20f
                val rad = Math.toRadians(angle.toDouble())
                val px = f.x + kotlin.math.cos(rad).toFloat() * size * 0.55f
                val py = f.y + kotlin.math.sin(rad).toFloat() * size * 0.55f
                canvas.drawCircle(px, py, size * 0.42f, paint)
            }
            paint.color = Color.HSVToColor(floatArrayOf((hue + 180) % 360f, 0.5f, 1f))
            canvas.drawCircle(f.x, f.y, size * (0.28f + m * 0.15f), paint)
        }

        // Pac-man's dot trail
        paint.color = if (isDarkTheme) Color.parseColor("#FFF7C2") else Color.parseColor("#7A5C00")
        for (d in dots) {
            if (!d.eaten) canvas.drawCircle(d.x, d.y, 7f, paint)
        }

        // Pac-man himself, mouth chomping to the beat
        val mouthAngle = 20f + (kotlin.math.abs(kotlin.math.sin(mouthPhase)) * 35f)
        paint.color = Color.parseColor("#FFD400")
        val facing = if (pacDir > 0) 0f else 180f
        canvas.drawArc(pacX - 30f, pacY - 30f, pacX + 30f, pacY + 30f, facing + mouthAngle, 360f - mouthAngle * 2f, true, paint)

        // Butterflies
        for (bf in butterflies) {
            val flap = kotlin.math.sin(time * 12f + bf.phase) * 0.5f + 0.5f
            paint.color = Color.HSVToColor(230, floatArrayOf((bf.hue + time * 20f) % 360f, 0.7f, 1f))
            val wingW = 26f * (0.4f + flap * 0.6f)
            canvas.drawOval(bf.x - wingW, bf.y - 20f, bf.x, bf.y, paint)
            canvas.drawOval(bf.x, bf.y - 20f, bf.x + wingW, bf.y, paint)
            canvas.drawOval(bf.x - wingW, bf.y, bf.x, bf.y + 18f, paint)
            canvas.drawOval(bf.x, bf.y, bf.x + wingW, bf.y + 18f, paint)
            paint.color = Color.parseColor("#3A2A1A")
            canvas.drawLine(bf.x, bf.y - 16f, bf.x, bf.y + 14f, paint)
        }
    }
}
